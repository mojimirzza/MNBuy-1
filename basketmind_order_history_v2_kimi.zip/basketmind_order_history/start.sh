#!/usr/bin/env sh
set -eu
exec python server.py
