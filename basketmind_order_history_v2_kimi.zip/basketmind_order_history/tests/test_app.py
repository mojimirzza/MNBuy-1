import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import server


class BasketMindTests(unittest.TestCase):
    def test_unwrap_orders_list_shape(self):
        payload = {"success": True, "data": {"items": {"orders": [{"trackingNumber": "SHOULD_NOT_REACH_AI"}]}, "totalRecords": 41}}
        parsed = server._unpack_page(payload)
        self.assertIsNotNone(parsed)
        self.assertEqual(len(parsed[0]), 1)
        self.assertEqual(parsed[1], 41)

    def test_safe_order_converts_rial_to_toman(self):
        result = server._safe_order({"orderTotalPay": 1250000, "customerOrderItems": [{"name": "شیر", "quantity": 2, "okPrice": 100000}]})
        self.assertEqual(result["amount_toman"], 125000)
        self.assertEqual(result["items"][0]["unit_price_toman"], 10000)
        self.assertEqual(result["items"][0]["name"], "شیر")

    def test_compact_context_does_not_include_tracking_number(self):
        order = server._safe_order({"trackingNumber": "SHOULD_NOT_REACH_AI", "createdOn": "2026-01-01", "totalAmount": 50000, "customerOrderItems": [{"name": "نان", "quantity": 1}]})
        compact = server._compact_orders([order])
        text = str(compact)
        self.assertNotIn("SHOULD_NOT_REACH_AI", text)
        self.assertIn("نان", text)

    def test_insights_counts_repeated_products(self):
        orders = [
            {"amount_toman": 1000, "items": [{"name": "شیر", "quantity": 1}]},
            {"amount_toman": 2000, "items": [{"name": "شیر", "quantity": 2}, {"name": "نان", "quantity": 1}]},
        ]
        result = server._insight_summary(orders, 20)
        self.assertEqual(result["orders_reviewed"], 2)
        self.assertEqual(result["sum_known_amounts_toman"], 3000)
        self.assertEqual(result["top_repeated_items"][0]["name"], "شیر")
        self.assertEqual(result["top_repeated_items"][0]["orders"], 2)
        self.assertIn("۳۰", result["coverage_note"])

    def test_missing_okala_token_is_clear(self):
        old = os.environ.pop("OKALA_ACCESS_TOKEN", None)
        try:
            data, status = server.get_okala_orders(1)
            self.assertEqual(status, 503)
            self.assertEqual(data["error"], "secret_missing")
        finally:
            if old is not None:
                os.environ["OKALA_ACCESS_TOKEN"] = old

    def test_chat_requires_consent(self):
        with self.assertRaises(server.ChatError) as ctx:
            server._chat_with_openrouter("سلام", [], False)
        self.assertEqual(ctx.exception.code, "consent_required")
        self.assertEqual(ctx.exception.status, 428)


if __name__ == "__main__":
    unittest.main()
