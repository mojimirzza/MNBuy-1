#!/usr/bin/env python3
"""BasketMind read-only purchase-history viewer. No cart or payment operations."""
from __future__ import annotations

import base64
import json
import math
import os
import threading
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HTML_PATH = ROOT / "static" / "index.html"
OKALA_URL = "https://apigateway.okala.com/api/v1/customerorders/list"
PAGE_SIZE = 10
TIMEOUT_SECONDS = 15


def _access_token() -> str:
    value = os.environ.get("OKALA_ACCESS_TOKEN", "").strip()
    if value.lower().startswith("bearer "):
        value = value[7:].strip()
    return value


def _customer_id(token: str) -> str:
    """Get the customer id from the token's JWT payload; token itself remains the authority."""
    override = os.environ.get("OKALA_CUSTOMER_ID", "").strip()
    if override:
        return override
    try:
        segment = token.split(".")[1]
        segment += "=" * ((4 - len(segment) % 4) % 4)
        claims = json.loads(base64.urlsafe_b64decode(segment.encode("ascii")))
        for name in ("userId", "customerId", "alternativeCustomerId", "sub"):
            value = claims.get(name)
            if value not in (None, ""):
                return str(value)
    except (IndexError, ValueError, UnicodeError, json.JSONDecodeError, TypeError):
        pass
    # The captured web page briefly sent "undefined" before its user context was loaded.
    # Keep the app simple for opaque tokens; set OKALA_CUSTOMER_ID only if the API needs it.
    return "undefined"


def _provider_get(token: str, customer_id: str, page_number: int) -> dict:
    query = urllib.parse.urlencode({
        "customerId": customer_id,
        "PageNumber": page_number,
        "PageSize": PAGE_SIZE,
    })
    req = urllib.request.Request(
        f"{OKALA_URL}?{query}",
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://www.okala.com",
            "Referer": "https://www.okala.com/profile/shopping-history",
            "X-Skip-Authorization": "false",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36",
        },
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as response:
        if response.status < 200 or response.status >= 300:
            raise RuntimeError("provider_http_error")
        raw = response.read(3_000_000)
    try:
        result = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise RuntimeError("provider_response_invalid") from None
    if not isinstance(result, dict):
        raise RuntimeError("provider_response_invalid")
    return result


def _unpack_page(payload: dict):
    if payload.get("success") is False:
        raise RuntimeError("provider_rejected_request")
    data = payload.get("data")
    if not isinstance(data, dict):
        return None
    raw_items = data.get("items")
    if isinstance(raw_items, dict):
        orders = raw_items.get("orders")
    elif isinstance(raw_items, list):
        orders = raw_items
    else:
        orders = None
    if not isinstance(orders, list):
        return None
    total = data.get("totalRecords")
    try:
        total = max(0, int(total))
    except (TypeError, ValueError):
        total = len(orders)
    return orders, total


def _safe_order(raw: dict) -> dict:
    amount = raw.get("orderTotalPay")
    if amount is None:
        amount = raw.get("totalAmountWithRefund")
    if amount is None:
        amount = raw.get("totalAmount")
    try:
        amount_toman = float(amount) / 10 if amount is not None else None
    except (TypeError, ValueError):
        amount_toman = None

    raw_products = raw.get("customerOrderItems")
    products = []
    if isinstance(raw_products, list):
        for product in raw_products:
            if not isinstance(product, dict):
                continue
            try:
                price = float(product.get("okPrice")) / 10 if product.get("okPrice") is not None else None
            except (TypeError, ValueError):
                price = None
            image_url = product.get("imageURL")
            if not isinstance(image_url, str) or not image_url.startswith("https://"):
                image_url = None
            products.append({
                "name": str(product.get("name") or "کالای بدون نام")[:180],
                "quantity": product.get("quantity", 1),
                "unit_price_toman": price,
                "image_url": image_url,
            })

    date_value = raw.get("createdDateTime") or raw.get("createdOn") or raw.get("shippingFinishTime") or ""
    tracking = raw.get("trackingNumber")
    return {
        "tracking_number": str(tracking) if tracking not in (None, "") else "",
        "date": str(date_value)[:80],
        "status": str(raw.get("badgeTitle") or raw.get("statusDescriptionForTicket") or raw.get("orderStateKey") or "وضعیت نامشخص")[:100],
        "store": str(raw.get("storeName") or raw.get("storeFullName") or "اکالا")[:120],
        "amount_toman": amount_toman,
        "items": products,
    }


def get_okala_orders(page: int) -> tuple[dict | None, int]:
    token = _access_token()
    if not token:
        return {"error": "secret_missing", "message": "سکرت OKALA_ACCESS_TOKEN برای Codespaces تنظیم نشده است."}, 503
    if page < 1 or page > 100:
        return {"error": "invalid_page", "message": "شماره صفحه نامعتبر است."}, 400

    customer_id = _customer_id(token)
    try:
        payload = _provider_get(token, customer_id, page)
        unpacked = _unpack_page(payload)
        # In the supplied capture, PageNumber=1 briefly returned data=0 while the UI
        # was still resolving customer context. A single zero-based fallback handles
        # that observed edge without retry loops.
        if unpacked is None and page == 1:
            payload = _provider_get(token, customer_id, 0)
            unpacked = _unpack_page(payload)
        if unpacked is None:
            return {"error": "unexpected_response", "message": "پاسخ تاریخچه اکالا قابل تشخیص نبود. توکن تازه را امتحان کنید؛ اگر ادامه داشت HAR جدید لازم است."}, 502
        raw_orders, total = unpacked
        orders = [_safe_order(item) for item in raw_orders if isinstance(item, dict)]
        return {
            "provider": "okala",
            "page": page,
            "page_size": PAGE_SIZE,
            "total_records": total,
            "total_pages": max(1, math.ceil(total / PAGE_SIZE)),
            "orders": orders,
        }, 200
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            return {"error": "token_expired", "message": "توکن اکالا نامعتبر یا منقضی شده است؛ مقدار سکرت OKALA_ACCESS_TOKEN را با access_token تازه جایگزین و Codespace را Restart کنید."}, 401
        if exc.code == 429:
            return {"error": "rate_limited", "message": "اکالا موقتاً درخواست‌های زیاد را محدود کرده است. کمی بعد دوباره امتحان کنید."}, 429
        return {"error": "provider_unavailable", "message": f"سرویس اکالا پاسخ مناسب نداد (HTTP {exc.code})."}, 502
    except (urllib.error.URLError, TimeoutError, OSError):
        return {"error": "network_error", "message": "اتصال Codespaces به سرویس اکالا برقرار نشد؛ شبکه یا دسترسی API را بررسی کنید."}, 502
    except RuntimeError:
        return {"error": "provider_response_invalid", "message": "پاسخ سرویس اکالا قابل پردازش نبود. احتمال تغییر API وجود دارد."}, 502
    except Exception:
        # Never include exception text: it can contain request details.
        return {"error": "internal_error", "message": "خطای داخلی؛ هیچ اطلاعات ورود یا توکنی نمایش داده نمی‌شود."}, 500


class Handler(BaseHTTPRequestHandler):
    server_version = "BasketMindOrderHistory/1.0"

    def log_message(self, fmt, *args):
        # Request paths contain only page numbers; avoid noisy/default access logs.
        return

    def _headers(self, content_type: str):
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'")

    def _json(self, body: dict, status: int = 200):
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._headers("application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/":
            try:
                data = HTML_PATH.read_bytes()
            except OSError:
                self.send_error(500, "UI file unavailable")
                return
            self.send_response(200)
            self._headers("text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if parsed.path == "/api/health":
            self._json({"ok": True, "okala_configured": bool(_access_token()), "providers": {"okala": "ready" if _access_token() else "missing_secret", "digikala_jet": "needs_har", "snapp_market": "needs_har"}})
            return
        if parsed.path == "/api/orders/okala":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                page = int(query.get("page", ["1"])[0])
            except (ValueError, TypeError):
                self._json({"error": "invalid_page", "message": "شماره صفحه نامعتبر است."}, 400)
                return
            body, status = get_okala_orders(page)
            self._json(body or {}, status)
            return
        self._json({"error": "not_found", "message": "مسیر پیدا نشد."}, 404)


def main():
    port = int(os.environ.get("PORT", "8080"))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"BasketMind Order History listening on 0.0.0.0:{port}; token configured={bool(_access_token())}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
