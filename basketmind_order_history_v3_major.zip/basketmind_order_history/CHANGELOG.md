# Changelog

## 3.0.0 — Major release
- Added durable SQLite cache for Okala orders and conversation messages.
- Added background paginated history sync with progress, bounded page cap, retry on transient provider failures, and partial-sync disclosure.
- Added deterministic aggregates: total, average, median, monthly order/spend series, status counts, unique products, repeated product/order counts, quantities, and conditional item-spend estimates.
- Added lexical retrieval for product/order relevance and earlier user/assistant turns; no vector DB or extra LLM request required.
- Added conversation restore after refresh and server-side deletion from the clear-chat control.
- Pinned inference to `openrouter/free`, ignoring a stale `OPENROUTER_MODEL` environment variable.
- Added fourteen offline unit tests and kept Okala read-only.
- Confirmed that unsupported Digikala Jet and Snapp Market integrations remain clearly marked as unavailable.
