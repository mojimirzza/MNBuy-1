import os
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import server


class BasketMindTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_data_dir, self.old_db_path = server.DATA_DIR, server.DB_PATH
        server.DATA_DIR = Path(self.tmp.name)
        server.DB_PATH = Path(self.tmp.name) / "test.sqlite3"
        server._init_db()

    def tearDown(self):
        server.DATA_DIR, server.DB_PATH = self.old_data_dir, self.old_db_path
        self.tmp.cleanup()

    def test_unwrap_orders_list_shape(self):
        payload = {"success": True, "data": {"items": {"orders": [{"trackingNumber": "SHOULD_NOT_REACH_AI"}]}, "totalRecords": 41}}
        parsed = server._unpack_page(payload)
        self.assertIsNotNone(parsed)
        self.assertEqual(len(parsed[0]), 1)
        self.assertEqual(parsed[1], 41)

    def test_safe_order_converts_rial_to_toman(self):
        result = server._safe_order({"orderTotalPay": 1250000, "customerOrderItems": [{"name": "شیر", "quantity": 2, "okPrice": 100000}]})
        self.assertEqual(result["amount_toman"], 125000)
        self.assertEqual(result["items"][0]["unit_price_toman"], 10000)
        self.assertEqual(result["items"][0]["name"], "شیر")

    def test_compact_context_does_not_include_tracking_number(self):
        order = server._safe_order({"trackingNumber": "TRACKING_SECRET_123", "createdOn": "2026-01-01", "totalAmount": 50000,
                                    "customerOrderItems": [{"name": "نان", "quantity": 1}]})
        compact = server._compact_orders([order])
        self.assertNotIn("TRACKING_SECRET_123", str(compact))
        self.assertIn("نان", str(compact))

    def test_insights_counts_repeated_products_and_months(self):
        orders = [
            {"date": "2026-03-01T10:00:00", "amount_toman": 1000, "status": "تحویل شده", "items": [{"name": "شیر", "quantity": 1}]},
            {"date": "2026-03-18T15:00:00", "amount_toman": 2000, "status": "تحویل شده", "items": [{"name": "شیر", "quantity": 2}, {"name": "نان", "quantity": 1}]},
        ]
        result = server._insight_summary(orders, 20)
        self.assertEqual(result["orders_reviewed"], 2)
        self.assertEqual(result["sum_known_amounts_toman"], 3000)
        self.assertEqual(result["average_known_order_toman"], 1500)
        self.assertEqual(result["top_repeated_items"][0]["name"], "شیر")
        self.assertEqual(result["top_repeated_items"][0]["orders"], 2)
        self.assertEqual(result["monthly_spend"][0]["month"], "2026-03")
        self.assertEqual(result["monthly_spend"][0]["spend_toman"], 3000)
        self.assertIn("تاریخچهٔ کامل همگام‌سازی نشده", result["coverage_note"])

    def test_missing_okala_token_is_clear(self):
        old = os.environ.pop("OKALA_ACCESS_TOKEN", None)
        try:
            data, status = server.get_okala_orders(1)
            self.assertEqual(status, 503)
            self.assertEqual(data["error"], "secret_missing")
        finally:
            if old is not None:
                os.environ["OKALA_ACCESS_TOKEN"] = old

    def test_model_always_uses_free_router_even_with_stale_override(self):
        old = os.environ.get("OPENROUTER_MODEL")
        os.environ["OPENROUTER_MODEL"] = "moonshotai/kimi-k2.6:free"
        try:
            self.assertEqual(server._openrouter_model(), "openrouter/free")
        finally:
            if old is None:
                os.environ.pop("OPENROUTER_MODEL", None)
            else:
                os.environ["OPENROUTER_MODEL"] = old

    def test_chat_requires_consent_before_network(self):
        with self.assertRaises(server.ChatError) as ctx:
            server._chat_with_openrouter("سلام", [], False)
        self.assertEqual(ctx.exception.code, "consent_required")
        self.assertEqual(ctx.exception.status, 428)

    def test_conversation_history_persists_in_sqlite(self):
        cid = "conversationtest123456"
        server._add_chat_message(cid, "user", "من معمولاً شیر کم‌چرب می‌خرم")
        server._add_chat_message(cid, "assistant", "متوجه شدم؛ شیر کم‌چرب را در تحلیل‌های بعدی در نظر می‌گیرم.")
        rows = server._get_chat_rows(cid)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["role"], "user")
        self.assertIn("شیر کم‌چرب", rows[0]["content"])

    def test_archive_retrieval_finds_older_relevant_turn(self):
        rows = []
        for i in range(9):
            rows.append({"role": "user", "content": f"موضوع عمومی شماره {i}"})
            rows.append({"role": "assistant", "content": f"پاسخ عمومی شماره {i}"})
        rows[0] = {"role": "user", "content": "من شیر کم‌چرب می‌خرم"}
        rows[1] = {"role": "assistant", "content": "ترجیح ثبت شد: شیر کم‌چرب"}
        matches = server._archive_retrieval(rows, "شیر کم‌چرب چه بود؟")
        self.assertTrue(matches)
        self.assertIn("شیر کم‌چرب", matches[0]["question"])

    def test_order_data_context_excludes_private_tracking_code(self):
        order = {"tracking_number": "PRIVATE_TRACKING_CODE", "date": "2026-01-01", "status": "تحویل", "store": "اکالا",
                 "amount_toman": 500, "items": [{"name": "ماست", "quantity": 1, "unit_price_toman": 500}]}
        context = server._build_data_context([order], 1, "ماست چند بار بوده؟", False)
        self.assertNotIn("PRIVATE_TRACKING_CODE", str(context))
        self.assertEqual(context["coverage"]["orders_in_context_dataset"], 1)

    def test_background_sync_saves_orders_and_marks_complete(self):
        old_token = os.environ.get("OKALA_ACCESS_TOKEN")
        os.environ["OKALA_ACCESS_TOKEN"] = "synthetic.test.token"
        payload = {"success": True, "data": {"items": {"orders": [
            {"trackingNumber": "SYN-1", "createdOn": "2026-03-01T10:00:00", "orderTotalPay": 10000,
             "customerOrderItems": [{"name": "شیر", "quantity": 1, "okPrice": 1000}]},
            {"trackingNumber": "SYN-2", "createdOn": "2026-03-02T10:00:00", "orderTotalPay": 20000,
             "customerOrderItems": [{"name": "نان", "quantity": 2, "okPrice": 2000}]},
        ]}, "totalRecords": 2}}
        try:
            with patch.object(server, "_provider_get", return_value=payload):
                server._sync_worker()
            self.assertEqual(server._cached_count(), 2)
            self.assertEqual(server._meta_get("sync_complete"), "true")
            self.assertEqual(server._meta_get("provider_total"), "2")
            self.assertEqual(len(server._cached_orders()), 2)
        finally:
            if old_token is None:
                os.environ.pop("OKALA_ACCESS_TOKEN", None)
            else:
                os.environ["OKALA_ACCESS_TOKEN"] = old_token

    def test_sync_limit_discloses_truncated_history(self):
        old_token = os.environ.get("OKALA_ACCESS_TOKEN")
        old_cap = server.MAX_SYNC_PAGES
        os.environ["OKALA_ACCESS_TOKEN"] = "synthetic.test.token"
        server.MAX_SYNC_PAGES = 1
        orders = [{"trackingNumber": f"SYN-{i}", "createdOn": f"2026-03-{i+1:02d}T10:00:00", "orderTotalPay": 1000,
                   "customerOrderItems": [{"name": "نان", "quantity": 1, "okPrice": 100}]} for i in range(10)]
        payload = {"success": True, "data": {"items": {"orders": orders}, "totalRecords": 12}}
        try:
            with patch.object(server, "_provider_get", return_value=payload):
                server._sync_worker()
            self.assertEqual(server._meta_get("sync_complete"), "false")
            self.assertEqual(server._meta_get("sync_truncated"), "true")
            summary = server._insight_summary(server._cached_orders(), 12)
            self.assertIn("سقف تنظیم‌شده", summary["coverage_note"])
        finally:
            server.MAX_SYNC_PAGES = old_cap
            if old_token is None:
                os.environ.pop("OKALA_ACCESS_TOKEN", None)
            else:
                os.environ["OKALA_ACCESS_TOKEN"] = old_token

    def test_persian_letter_and_digit_normalization(self):
        self.assertEqual(server._normalize_text("كيك ۱۲۳"), server._normalize_text("کیک 123"))

    def test_valid_conversation_id(self):
        self.assertEqual(server._validate_conversation_id("abc123456789"), "abc123456789")
        with self.assertRaises(server.ChatError):
            server._validate_conversation_id("../bad")


if __name__ == "__main__":
    unittest.main(verbosity=2)
