import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from apply_upgrade import OLD_CONTEXT, OLD_GATE, patch_server


class UpgradePatcherTests(unittest.TestCase):
    def test_patch_preserves_consent_and_adds_local_agent_before_openrouter_call(self):
        source = '''from typing import Any

def _chat_with_openrouter(user_message, history, consent, archived=None):
''' + OLD_GATE + '''    except ChatError:
        raise
    context = _build_data_context(orders, total_records, user_message, synchronized)
    system_prompt = (
        "در پاسخ، وقتی مفید است دامنهٔ داده و تعداد سفارش بررسی‌شده را ذکر کن؛ معمولاً مختصر، روشن و کاربردی باش.\\n\\n"
    )
    return system_prompt

class Handler:
    server_version = "BasketMind/3.0"
    def health(self):
        return {"version": "3.0.0"}

def main():
    print("BasketMind v3.0 listening")
'''
        patched = patch_server(source)
        self.assertIn("from analytics_agent import run_analytics_agent", patched)
        self.assertIn('"version": "3.1.0"', patched)
        self.assertIn("context[\"analytics_agent\"] = agent_public", patched)
        self.assertLess(patched.index("if not consent:"), patched.index("if agent_result.get(\"status\") == \"verified\""))
        self.assertLess(patched.index("if agent_result.get(\"status\") == \"verified\""), patched.index("key = _openrouter_key()"))
        self.assertIn("فیلد analytics_agent", patched)
        compile(patched, "patched_server_fixture.py", "exec")

    def test_patched_chat_returns_verified_numbers_before_openrouter_key_lookup(self):
        prefix = '''from typing import Any

class ChatError(Exception):
    def __init__(self, code, message="", status=500):
        self.code, self.message, self.status = code, message, status

ORDERS = [{"date": "2026-01-01", "amount_toman": 90000, "status": "تحویل شده",
           "items": [{"name": "نان", "quantity": 2}]}]
def _cached_orders(): return ORDERS
def _meta_get(key, default=""):
    return {"provider_total": "1", "last_synced_at": "2026-01-01", "sync_complete": "true", "sync_truncated": "false"}.get(key, default)
def _build_data_context(orders, total, query, synchronized):
    return {"coverage": {"complete_sync": True, "scope": "همگام‌سازی کامل", "note": ""}}
def _fetch_recent_orders(): raise AssertionError("fresh provider request must not be needed")
def _openrouter_key(): raise AssertionError("verified numerical answer must bypass OpenRouter")
def _chat_with_openrouter(user_message, history, consent, archived=None):
'''
        suffix = '''    except ChatError:
        raise
    cached_total = _meta_get("provider_total", "")
    total_records = int(cached_total) if cached_total.isdigit() else 0
    synchronized = bool(orders) and _meta_get("last_synced_at", "") != ""
    context = _build_data_context(orders, total_records, user_message, synchronized)
    system_prompt = (
        "test"
    )
    return {"ok": False}
'''
        patched = patch_server(prefix + OLD_GATE + suffix)
        namespace = {}
        exec(compile(patched, "integrated_patched_server.py", "exec"), namespace)
        result = namespace["_chat_with_openrouter"]("مجموع مبلغ کل سفارش‌ها چقدر بوده؟", [], True)
        self.assertTrue(result["ok"])
        self.assertIn("90,000 تومان", result["answer"])
        self.assertTrue(result["analytics_agent"]["harness"]["passed"])

    def test_patch_rejects_unknown_source_without_modifying_it(self):
        with self.assertRaises(RuntimeError):
            patch_server("from typing import Any\n# different source\n")


if __name__ == "__main__":
    unittest.main()
