import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from analytics_agent import _harness_validate, normalize_text, run_analytics_agent


class AnalyticsAgentTests(unittest.TestCase):
    def setUp(self):
        self.orders = [
            {
                "date": "2026-01-03T10:00:00",
                "amount_toman": 200000,
                "status": "تحویل شده",
                "items": [
                    {"name": "شیر", "quantity": 1, "unit_price_toman": 30000},
                    {"name": "شیر کم‌چرب", "quantity": 2, "unit_price_toman": 25000},
                ],
            },
            {
                "date": "2026-02-17T11:00:00",
                "amount_toman": 300000,
                "status": "تحویل شده",
                "items": [
                    {"name": "شیر کم چرب", "quantity": 3, "unit_price_toman": 28000},
                    {"name": "نان", "quantity": 2},
                ],
            },
            {
                "date": "2026-02-25T15:00:00",
                "amount_toman": None,
                "status": "در انتظار",
                "items": [{"name": "شیر کم چرب", "quantity": 1}],
            },
        ]
        self.complete = {"complete_sync": True, "scope": "تمام سفارش‌های ذخیره‌شده", "note": ""}
        self.partial = {"complete_sync": False, "scope": "نمونه محدود", "note": "تاریخچه کامل همگام‌سازی نشده است."}

    def test_persian_normalization_and_digits(self):
        self.assertEqual(normalize_text("كاله ۱۲۳ يکتا"), "کاله 123 یکتا")

    def test_product_frequency_uses_all_matching_orders(self):
        result = run_analytics_agent(self.orders, "شیر کم چرب را چند بار خریدم و چند عدد بوده؟", self.complete)
        self.assertEqual(result["status"], "verified")
        self.assertEqual(result["intent"], "product_frequency")
        self.assertEqual(result["matched_product"], "شیر کم‌چرب")
        self.assertEqual(result["evidence"]["orders_with_product"], 3)
        self.assertEqual(result["evidence"]["quantity_total"], 6)
        self.assertTrue(result["harness"]["passed"])

    def test_product_spend_does_not_attribute_whole_order_total(self):
        result = run_analytics_agent(self.orders, "مجموع هزینه شیر کم چرب چقدر بوده؟", self.complete)
        self.assertEqual(result["status"], "verified")
        self.assertEqual(result["intent"], "product_spend")
        self.assertEqual(result["evidence"]["known_line_spend_toman"], 134000)
        self.assertEqual(result["evidence"]["priced_quantity"], 5)
        self.assertEqual(result["evidence"]["unpriced_quantity"], 1)
        self.assertIn("کامل نیست", result["direct_answer"])
        self.assertNotIn("500,000 تومان", result["direct_answer"])

    def test_price_query_in_toman_routes_to_price_history_not_spend(self):
        result = run_analytics_agent(self.orders, "قیمت شیر کم چرب چند تومان بوده؟", self.complete)
        self.assertEqual(result["intent"], "product_price_range")
        self.assertEqual(result["evidence"]["min_unit_price_toman"], 25000)
        self.assertEqual(result["evidence"]["max_unit_price_toman"], 28000)

    def test_no_recorded_product_price_is_disclosed(self):
        result = run_analytics_agent(self.orders, "برای نان چقدر هزینه کردم؟", self.complete)
        self.assertEqual(result["status"], "verified")
        self.assertIn("قیمت واحد", result["direct_answer"])
        self.assertIn("نمی‌توان", result["direct_answer"])

    def test_total_spend_is_recalculated_by_harness(self):
        result = run_analytics_agent(self.orders, "مجموع مبلغ کل سفارش‌ها چقدر بوده؟", self.complete)
        self.assertEqual(result["intent"], "total_spend")
        self.assertEqual(result["evidence"]["sum_known_amounts_toman"], 500000)
        self.assertTrue(result["harness"]["passed"])
        forged = dict(result)
        forged["evidence"] = dict(result["evidence"], sum_known_amounts_toman=1)
        ok, checks = _harness_validate(self.orders, forged)
        self.assertFalse(ok)
        self.assertIn("total_spend_recalculation_failed", checks)

    def test_missing_order_amounts_are_not_reported_as_zero_spend(self):
        orders = [{"date": "2026-03-01", "amount_toman": None, "items": [{"name": "نان", "quantity": 1}]}]
        result = run_analytics_agent(orders, "مجموع مبلغ کل سفارش‌ها چقدر بوده؟", self.complete)
        self.assertEqual(result["status"], "verified")
        self.assertIsNone(result["evidence"]["sum_known_amounts_toman"])
        self.assertIn("جمع قابل محاسبه نیست", result["direct_answer"])

    def test_partial_sync_warning_is_always_disclosed(self):
        result = run_analytics_agent(self.orders, "مجموع مبلغ کل سفارش‌ها چقدر بوده؟", self.partial)
        self.assertEqual(result["status"], "verified")
        self.assertIn("محدودیت داده", result["direct_answer"])
        self.assertIn("تاریخچه کامل همگام‌سازی نشده", result["direct_answer"])

    def test_monthly_totals_match_source_data(self):
        result = run_analytics_agent(self.orders, "روند مبلغ خریدها به تفکیک ماه را بگو", self.complete)
        self.assertEqual(result["intent"], "monthly_spend")
        self.assertEqual(result["evidence"]["monthly"][0], {"month": "2026-01", "orders": 1, "orders_with_amount": 1, "known_spend_toman": 200000})
        self.assertEqual(result["evidence"]["monthly"][1], {"month": "2026-02", "orders": 2, "orders_with_amount": 1, "known_spend_toman": 300000})

    def test_top_repeated_products_pass_harness(self):
        result = run_analytics_agent(self.orders, "کدام کالاها را بیشتر خریدم؟", self.complete)
        self.assertEqual(result["intent"], "top_products")
        self.assertTrue(result["harness"]["passed"])
        self.assertEqual(result["evidence"]["top_products"][0]["key"], normalize_text("شیر کم چرب"))

    def test_unsupported_query_does_not_create_direct_answer(self):
        result = run_analytics_agent(self.orders, "آیا فردا اکالا تخفیف می‌دهد؟", self.complete)
        self.assertEqual(result["status"], "unsupported")
        self.assertIsNone(result["direct_answer"])

    def test_explanatory_product_question_falls_back_instead_of_fake_certainty(self):
        result = run_analytics_agent(self.orders, "چرا شیر کم چرب گران شده؟", self.complete)
        self.assertEqual(result["status"], "verified")
        self.assertEqual(result["intent"], "product_explanation_or_advice")
        self.assertTrue(result["harness"]["passed"])
        self.assertIsNone(result["direct_answer"])


if __name__ == "__main__":
    unittest.main()
