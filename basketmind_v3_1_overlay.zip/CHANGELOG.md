# Changelog

## 3.1.0 — Python-first analytics agent + harness
- Added a local tool router for supported quantitative questions.
- Added independent evidence checks before deterministic answers are returned.
- Avoids attributing full order totals to a specific product when item-level unit prices are absent.
- Discloses incomplete history sync in direct analytical answers.
- Verified analytical answers pass the existing UI consent gate but do not call OpenRouter; general/ambiguous answers retain the existing `openrouter/free` path.
- Leaves SQLite data, existing UI, and retailer integrations intact.
- Added offline tests; no live retailer or OpenRouter calls are made by those tests.
