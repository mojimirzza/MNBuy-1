#!/usr/bin/env python3
"""Safely apply the BasketMind v3.1 Python-first analytics agent overlay."""
from __future__ import annotations

import argparse
import py_compile
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

OLD_GATE = '''    if not consent:
        raise ChatError("consent_required", "برای فرستادن خلاصه سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی، ابتدا اجازه‌ات را تأیید کن.", 428)
    archived = archived or []
    key = _openrouter_key()
    if not key:
        raise ChatError("openrouter_key_missing", "سکرت OPENROUTER_API_KEY در محیط سرور پیدا نشد. آن را در بخش Codespaces Secrets بررسی کن.", 503)
    try:
        orders = _cached_orders()
'''
NEW_GATE = '''    if not consent:
        raise ChatError("consent_required", "برای فرستادن خلاصه سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی، ابتدا اجازه‌ات را تأیید کن.", 428)
    archived = archived or []
    try:
        orders = _cached_orders()
'''
OLD_CONTEXT = '''    context = _build_data_context(orders, total_records, user_message, synchronized)
    system_prompt = (
'''
NEW_CONTEXT = '''    context = _build_data_context(orders, total_records, user_message, synchronized)
    try:
        agent_result = run_analytics_agent(orders, user_message, context.get("coverage", {}))
    except Exception:
        # A local analytics defect must not take down the existing chat path.
        agent_result = {"status": "agent_error", "tool": "fallback_to_llm", "intent": "unknown",
                        "matched_product": None, "evidence": {}, "direct_answer": None,
                        "harness": {"passed": False, "checks": ["agent_exception"]}}
    agent_public = {
        "status": agent_result.get("status"), "tool": agent_result.get("tool"),
        "intent": agent_result.get("intent"), "matched_product": agent_result.get("matched_product"),
        "evidence": agent_result.get("evidence", {}) if agent_result.get("harness", {}).get("passed") is True else {},
        "harness": agent_result.get("harness", {}),
    }
    # Verified numerical answers are produced locally: no model latency, no model fee,
    # and no risk of an LLM changing arithmetic. Chat history remains in local SQLite.
    if agent_result.get("status") == "verified" and agent_result.get("harness", {}).get("passed") is True and agent_result.get("direct_answer"):
        return {"ok": True, "answer": agent_result["direct_answer"],
                "model": "BasketMind Python analytics agent v3.1 (local)",
                "orders_reviewed": len(orders), "data_scope": context["coverage"], "usage": None,
                "analytics_agent": agent_public}
    context["analytics_agent"] = agent_public
    # The existing UI consent gate is preserved; verified analytics skip OpenRouter after consent.
    key = _openrouter_key()
    if not key:
        raise ChatError("openrouter_key_missing", "سکرت OPENROUTER_API_KEY در محیط سرور پیدا نشد. آن را در بخش Codespaces Secrets بررسی کن.", 503)
    system_prompt = (
'''


def patch_server(source: str) -> str:
    if 'from analytics_agent import run_analytics_agent' in source:
        raise RuntimeError("نسخهٔ عامل تحلیلی قبلاً به server.py اضافه شده است؛ از اجرای دوباره خودداری شد.")
    if '    context = _build_data_context(orders, total_records, user_message, synchronized)\n    system_prompt = (\n' not in source:
        raise RuntimeError("محل ادغام context پیدا نشد؛ فایل ناشناخته است و تغییری اعمال نشد.")
    if OLD_GATE not in source:
        raise RuntimeError("بخش اولیهٔ consent/chat با نسخهٔ مورد انتظار مطابقت ندارد؛ تغییری اعمال نشد.")
    updated = source.replace('from typing import Any\n', 'from typing import Any\n\nfrom analytics_agent import run_analytics_agent\n', 1)
    updated = updated.replace(OLD_GATE, NEW_GATE, 1)
    updated = updated.replace(OLD_CONTEXT, NEW_CONTEXT, 1)
    prompt_anchor = '        "در پاسخ، وقتی مفید است دامنهٔ داده و تعداد سفارش بررسی‌شده را ذکر کن؛ معمولاً مختصر، روشن و کاربردی باش.\\n\\n"\n'
    prompt_replacement = '        "فیلد analytics_agent نتیجهٔ انتخاب ابزار و بررسی قطعی Harness است؛ اگر status برابر unsupported است یا Harness تأیید نشده، عدد تازه نساز. در سؤال‌های توضیحی، واقعیت ثبت‌شده را از علت یا حدس جدا کن و علتِ اثبات‌نشده نساز. "\n' + prompt_anchor
    if prompt_anchor in updated:
        updated = updated.replace(prompt_anchor, prompt_replacement, 1)
    if OLD_GATE in updated or OLD_CONTEXT in updated:
        raise RuntimeError("تغییر همهٔ نقاط ادغام تأیید نشد؛ تغییری ذخیره نشد.")
    updated = updated.replace('server_version = "BasketMind/3.0"', 'server_version = "BasketMind/3.1"')
    updated = updated.replace('"version": "3.0.0"', '"version": "3.1.0"')
    updated = updated.replace('BasketMind v3.0 listening', 'BasketMind v3.1 listening')
    return updated


def main() -> int:
    parser = argparse.ArgumentParser(description="Upgrade an existing BasketMind v3 installation without deleting its data.")
    parser.add_argument("--app-dir", default="basketmind_order_history", help="Folder containing server.py, static/ and tests/ (default: basketmind_order_history)")
    args = parser.parse_args()
    app_dir = Path(args.app_dir).expanduser().resolve()
    if not (app_dir.is_dir() and (app_dir / "server.py").is_file()):
        current_dir = Path.cwd().resolve()
        if (current_dir / "server.py").is_file():
            app_dir = current_dir
        else:
            print(f"خطا: پوشهٔ برنامه یا server.py پیدا نشد: {app_dir}", file=sys.stderr)
            print("مسیر پوشهٔ برنامه را با --app-dir مشخص کن؛ فایل اصلی در این حالت تغییر نمی‌کند.", file=sys.stderr)
            return 2

    overlay_dir = Path(__file__).resolve().parent
    source_path = app_dir / "server.py"
    original = source_path.read_text(encoding="utf-8")
    try:
        updated = patch_server(original)
    except RuntimeError as exc:
        print(f"عدم اعمال تغییر: {exc}", file=sys.stderr)
        return 3

    module_src = overlay_dir / "analytics_agent.py"
    test_src = overlay_dir / "tests" / "test_analytics_agent.py"
    if not module_src.is_file() or not test_src.is_file():
        print("خطا: فایل‌های overlay ناقص هستند؛ فایل اصلی تغییر نکرد.", file=sys.stderr)
        return 4

    # Save original source before any writes. Existing .data/ and SQLite history are untouched.
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    backup_dir = app_dir / ".data" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup = backup_dir / f"server.py.bak-v3.1-{stamp}"
    shutil.copy2(source_path, backup)
    target_module = app_dir / "analytics_agent.py"
    target_module.write_text(module_src.read_text(encoding="utf-8"), encoding="utf-8")
    test_dir = app_dir / "tests"
    test_dir.mkdir(exist_ok=True)
    shutil.copy2(test_src, test_dir / "test_analytics_agent.py")
    notes_src = overlay_dir / "RELEASE_NOTES_FA.md"
    if notes_src.is_file():
        shutil.copy2(notes_src, app_dir / "RELEASE_NOTES_V3_1_FA.md")
    version_src = overlay_dir / "VERSION"
    if version_src.is_file():
        shutil.copy2(version_src, app_dir / "VERSION")
    changelog_src = overlay_dir / "CHANGELOG.md"
    if changelog_src.is_file():
        shutil.copy2(changelog_src, app_dir / "CHANGELOG_V3_1.md")

    try:
        source_path.write_text(updated, encoding="utf-8")
        py_compile.compile(str(target_module), doraise=True)
        py_compile.compile(str(source_path), doraise=True)
    except Exception as exc:
        source_path.write_text(original, encoding="utf-8")
        print(f"خطا در بررسی نحوی؛ server.py از نسخهٔ پشتیبان بازگردانده شد: {exc}", file=sys.stderr)
        print(f"نسخهٔ پشتیبان: {backup}", file=sys.stderr)
        return 5

    print("BasketMind v3.1 افزوده شد.")
    print(f"برنامه: {app_dir}")
    print(f"نسخهٔ پشتیبان server.py: {backup}")
    print("پوشهٔ .data و پایگاه SQLite حذف یا بازنویسی نشده‌اند.")
    print("اکنون این دو دستور را از همین پوشه اجرا کن:")
    print("  python -m unittest discover -s tests -v")
    print("  python server.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
