"""Python-first analytical tool router and deterministic output harness for BasketMind.

No external packages, embeddings, second LLM call, or provider write operations.
The agent routes supported factual questions to local analytics; the harness independently
rechecks the key evidence before allowing a deterministic answer to be returned.
"""
from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter, defaultdict
from datetime import datetime
from statistics import median
from typing import Any

PERSIAN_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
CHAR_MAP = str.maketrans({"ي": "ی", "ى": "ی", "ك": "ک", "ۀ": "ه", "ة": "ه", "أ": "ا", "إ": "ا"})
UNKNOWN_NAMES = {"کالای بدون نام", "نامشخص", "unknown"}


def normalize_text(value: Any) -> str:
    value = unicodedata.normalize("NFKC", str(value or "")).translate(CHAR_MAP).translate(PERSIAN_DIGITS).lower()
    value = re.sub(r"[\u064b-\u065f\u0670\u0640]", "", value)
    value = re.sub(r"[^\w\u0600-\u06ff]+", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def _finite_number(value: Any) -> float | None:
    try:
        number = float(str(value).translate(PERSIAN_DIGITS).replace(",", "").strip())
        return number if math.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def _quantity(item: dict[str, Any]) -> float:
    number = _finite_number(item.get("quantity", 1))
    return max(0.0, number if number is not None else 1.0)


def _unit_price(item: dict[str, Any]) -> float | None:
    price = _finite_number(item.get("unit_price_toman"))
    return price if price is not None and price >= 0 else None


def _amount(order: dict[str, Any]) -> float | None:
    amount = _finite_number(order.get("amount_toman"))
    return amount if amount is not None else None


def _fmt(value: float | int | None) -> str:
    if value is None:
        return "نامشخص"
    rounded = round(float(value), 2)
    if abs(rounded - round(rounded)) < 1e-9:
        return f"{int(round(rounded)):,}"
    return f"{rounded:,.2f}"


def _month_key(value: Any) -> str:
    text = str(value or "").translate(PERSIAN_DIGITS)
    match = re.search(r"(?<!\d)(\d{4})[-/.](\d{1,2})(?:[-/.](\d{1,2}))?", text)
    if match:
        year, month = int(match.group(1)), int(match.group(2))
        if 1 <= month <= 12:
            return f"{year:04d}-{month:02d}"
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).strftime("%Y-%m")
    except (ValueError, TypeError):
        return ""


def _catalog(orders: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for order_index, order in enumerate(orders):
        items = order.get("items", [])
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            name = re.sub(r"\s+", " ", str(item.get("name") or "")).strip()
            key = normalize_text(name)
            if not key or key in {normalize_text(x) for x in UNKNOWN_NAMES}:
                continue
            entry = result.setdefault(key, {
                "key": key, "name": name, "order_indices": set(), "quantity": 0.0,
                "priced_quantity": 0.0, "unpriced_quantity": 0.0, "known_line_spend": 0.0,
                "prices": [], "item_lines": 0,
            })
            entry["order_indices"].add(order_index)
            entry["quantity"] += _quantity(item)
            entry["item_lines"] += 1
            price = _unit_price(item)
            if price is None:
                entry["unpriced_quantity"] += _quantity(item)
            else:
                entry["priced_quantity"] += _quantity(item)
                entry["known_line_spend"] += price * _quantity(item)
                entry["prices"].append({"price": price, "date": str(order.get("date") or "")})
    return result


def _match_product(query: str, catalog: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
    normalized_query = normalize_text(query)
    # Longest exact phrase wins: «شیر کم چرب» must not be reduced to «شیر».
    for key in sorted(catalog, key=lambda value: (len(value), value), reverse=True):
        if re.search(r"(?<!\w)" + re.escape(key) + r"(?!\w)", normalized_query, flags=re.UNICODE):
            return catalog[key]
    return None


def _coverage_suffix(coverage: dict[str, Any]) -> str:
    if coverage.get("complete_sync") is True:
        return ""
    note = str(coverage.get("note") or "").strip()
    if not note:
        note = "کامل‌بودن همگام‌سازی تاریخچه تأیید نشده است؛ نتیجه را فقط به سفارش‌های موجود تعمیم بده."
    return "\n\nمحدودیت داده: " + note


def _known_amounts(orders: list[dict[str, Any]]) -> list[float]:
    return [value for order in orders if (value := _amount(order)) is not None]


def _base_evidence(orders: list[dict[str, Any]], tool: str) -> dict[str, Any]:
    return {"tool": tool, "source": "SQLite order cache + Python", "orders_considered": len(orders)}


def _build_plan(orders: list[dict[str, Any]], query: str, coverage: dict[str, Any]) -> dict[str, Any]:
    q = normalize_text(query)
    catalog = _catalog(orders)
    product = _match_product(query, catalog)
    money_words = ("هزینه", "مبلغ", "خرج", "پول", "پرداخت", "صرف کردم", "صرف شده", "چقدر هزینه")
    price_words = ("قیمت", "گران", "گرون", "ارزان", "ارزون", "تغییر قیمت", "قیمتش")
    frequency_words = ("چند بار", "چند دفعه", "چند مرتبه", "دفعات خرید", "تعداد سفارش", "چند سفارش")
    quantity_words = ("چند عدد", "چند تا", "چند کیلو", "چقدر خریدم", "چه مقدار", "مقدار خرید", "تعداد واحد", "چند بسته")
    total_money_words = ("مجموع هزینه", "جمع هزینه", "کل هزینه", "چقدر خرج", "چقدر هزینه", "مجموع مبلغ", "جمع مبلغ", "مبلغ کل", "کل مبالغ", "چقدر پرداخت", "هزینه کلی", "صرف کردم")

    def result(tool: str, intent: str, evidence: dict[str, Any], answer: str) -> dict[str, Any]:
        evidence["tool"] = tool
        return {"status": "pending_validation", "tool": tool, "intent": intent,
                "matched_product": product["name"] if product else None,
                "evidence": evidence, "direct_answer": answer + _coverage_suffix(coverage)}

    if product is not None:
        entry = product
        product_evidence = _base_evidence(orders, "product_analysis")
        product_evidence.update({
            "product_key": entry["key"], "product_name": entry["name"],
            "orders_with_product": len(entry["order_indices"]),
            "quantity_total": round(entry["quantity"], 4),
            "priced_quantity": round(entry["priced_quantity"], 4),
            "unpriced_quantity": round(entry["unpriced_quantity"], 4),
            "known_line_spend_toman": round(entry["known_line_spend"], 2),
            "price_observations": len(entry["prices"]),
            "min_unit_price_toman": min((x["price"] for x in entry["prices"]), default=None),
            "max_unit_price_toman": max((x["price"] for x in entry["prices"]), default=None),
        })
        if any(word in q for word in ("چرا", "دلیل", "به نظرت", "پیشنهاد", "چه کنم", "چطور بهتر", "به صرفه")):
            return {"status": "pending_validation", "tool": "product_analysis", "intent": "product_explanation_or_advice",
                    "matched_product": entry["name"], "evidence": product_evidence, "direct_answer": None}
        asks_money = any(word in q for word in money_words) or any(word in q for word in ("مجموع هزینه", "قیمت کل"))
        asks_price = any(word in q for word in price_words)
        asks_frequency = any(word in q for word in frequency_words)
        asks_quantity = any(word in q for word in quantity_words)

        if asks_money:
            if entry["priced_quantity"] > 0:
                answer = (f"برای «{entry['name']}»، برآورد مبلغ اقلام بر پایهٔ قیمت واحد ثبت‌شده "
                          f"{_fmt(entry['known_line_spend'])} تومان است؛ این محاسبه قیمتِ ثبت‌شده را برای "
                          f"{_fmt(entry['priced_quantity'])} واحد پوشش می‌دهد.")
                if entry["unpriced_quantity"] > 0:
                    answer += f" قیمت واحدِ {_fmt(entry['unpriced_quantity'])} واحد در داده‌ها ثبت نشده، پس جمع بالا کامل نیست."
            else:
                answer = (f"«{entry['name']}» در {len(entry['order_indices'])} سفارش و به تعداد {_fmt(entry['quantity'])} واحد دیده می‌شود، "
                          "اما قیمت واحد کالا در داده‌های موجود ثبت نشده است. از مبلغ کل سفارش‌ها نمی‌توان هزینهٔ همین کالا را جداگانه محاسبه کرد.")
            return result("product_line_spend", "product_spend", product_evidence, answer)

        if asks_price:
            prices = entry["prices"]
            if not prices:
                answer = (f"برای «{entry['name']}» قیمت واحدِ قابل‌استفاده‌ای در تاریخچهٔ موجود پیدا نشد؛ "
                          "بنابراین نمی‌توانم تغییر قیمت آن را با دادهٔ فعلی تأیید کنم.")
            else:
                low = min(prices, key=lambda x: x["price"])
                high = max(prices, key=lambda x: x["price"])
                answer = (f"در {len(prices)} مشاهدهٔ قیمت واحد ثبت‌شده برای «{entry['name']}»، "
                          f"کمترین قیمت {_fmt(low['price'])} تومان و بیشترین قیمت {_fmt(high['price'])} تومان است.")
                if low.get("date"):
                    answer += f" تاریخ مشاهدهٔ کمترین قیمت: {low['date']}."
                if high.get("date"):
                    answer += f" تاریخ مشاهدهٔ بیشترین قیمت: {high['date']}."
                answer += " این فقط مقایسهٔ قیمت‌های ثبت‌شده است، نه تضمین تغییر پیوستهٔ قیمت در تمام روزها."
            return result("product_price_history", "product_price_range", product_evidence, answer)

        if asks_frequency or asks_quantity:
            answer = (f"«{entry['name']}» در {len(entry['order_indices'])} سفارش از داده‌های بررسی‌شده آمده "
                      f"و مجموع تعداد ثبت‌شده {_fmt(entry['quantity'])} واحد است.")
            return result("product_purchase_frequency", "product_frequency", product_evidence, answer)

        if not any(word in q for word in ("آمار", "خلاصه خرید", "خلاصهٔ خرید", "خلاصه سفارش", "خلاصهٔ سفارش", "رفتار خرید", "اطلاعات خرید")):
            return {"status": "pending_validation", "tool": "product_analysis", "intent": "general_or_ambiguous_product_question",
                    "matched_product": entry["name"], "evidence": product_evidence, "direct_answer": None}

        # An explicit summary request may be answered locally from the matched product facts.
        answer = (f"در داده‌های بررسی‌شده، «{entry['name']}» در {len(entry['order_indices'])} سفارش آمده "
                  f"و مجموع تعداد ثبت‌شده {_fmt(entry['quantity'])} واحد است.")
        if entry["priced_quantity"] > 0:
            answer += f" برآورد مبلغ برای واحدهای دارای قیمت ثبت‌شده: {_fmt(entry['known_line_spend'])} تومان."
            if entry["unpriced_quantity"] > 0:
                answer += f" قیمت {_fmt(entry['unpriced_quantity'])} واحد ثبت نشده است."
        else:
            answer += " قیمت واحد اقلام ثبت نشده و جمع هزینهٔ اختصاصی کالا قابل محاسبه نیست."
        return result("product_summary", "product_summary", product_evidence, answer)

    known_amounts = _known_amounts(orders)
    total = round(sum(known_amounts), 2)
    if any(word in q for word in total_money_words):
        evidence = _base_evidence(orders, "total_known_order_amounts")
        evidence.update({"known_amounts_count": len(known_amounts),
                         "sum_known_amounts_toman": round(total, 2) if known_amounts else None})
        if known_amounts:
            answer = (f"در {len(orders)} سفارش بررسی‌شده، مبلغ {len(known_amounts)} سفارش ثبت شده است؛ "
                      f"جمع مبالغ ثبت‌شده {_fmt(total)} تومان است.")
        else:
            answer = f"از {len(orders)} سفارش بررسی‌شده، هیچ مبلغ سفارشی در دادهٔ موجود ثبت نشده؛ بنابراین جمع قابل محاسبه نیست."
        return result("total_spend", "total_spend", evidence, answer)

    if any(word in q for word in ("میانگین", "متوسط مبلغ", "متوسط هر سفارش")):
        avg = round(sum(known_amounts) / len(known_amounts), 2) if known_amounts else None
        evidence = _base_evidence(orders, "average_order_amount")
        evidence.update({"known_amounts_count": len(known_amounts), "average_known_order_toman": avg})
        answer = (f"میانگین مبلغ سفارش‌های دارای مبلغ ثبت‌شده {_fmt(avg)} تومان است؛ "
                  f"محاسبه روی {len(known_amounts)} سفارش از {len(orders)} سفارش بررسی‌شده انجام شد.")
        return result("average_order_amount", "average_order_amount", evidence, answer)

    if any(word in q for word in ("میانه", "میانه مبلغ")):
        med = round(float(median(known_amounts)), 2) if known_amounts else None
        evidence = _base_evidence(orders, "median_order_amount")
        evidence.update({"known_amounts_count": len(known_amounts), "median_known_order_toman": med})
        answer = (f"میانهٔ مبلغ سفارش‌های دارای مبلغ ثبت‌شده {_fmt(med)} تومان است؛ "
                  f"محاسبه روی {len(known_amounts)} سفارش انجام شد.")
        return result("median_order_amount", "median_order_amount", evidence, answer)

    if any(word in q for word in ("ماهانه", "ماهیانه", "هر ماه", "روند ماه", "تفکیک ماه", "به تفکیک ماه")):
        spends: Counter[str] = Counter()
        counts: Counter[str] = Counter()
        amount_counts: Counter[str] = Counter()
        for order in orders:
            month = _month_key(order.get("date"))
            amount = _amount(order)
            if month:
                counts[month] += 1
                if amount is not None:
                    spends[month] += amount
                    amount_counts[month] += 1
        monthly = [{"month": month, "orders": counts[month], "orders_with_amount": amount_counts[month],
                    "known_spend_toman": round(spends[month], 2) if amount_counts[month] else None}
                   for month in sorted(counts)]
        evidence = _base_evidence(orders, "monthly_spend")
        evidence["monthly"] = monthly
        if monthly:
            answer = "مبالغ ثبت‌شده به تفکیک ماه در داده‌های موجود:\n" + "\n".join(
                f"{row['month']}: {_fmt(row['known_spend_toman'])} تومان ({row['orders']} سفارش؛ مبلغ برای {row['orders_with_amount']} سفارش ثبت شده)" for row in monthly[-18:])
        else:
            answer = "تاریخ‌های سفارش در قالب قابل‌گروه‌بندی پیدا نشدند؛ روند ماهانه را با اطمینان نمی‌توان محاسبه کرد."
        return result("monthly_spend", "monthly_spend", evidence, answer)

    if any(word in q for word in ("پرتکرار", "بیشتر خریدم", "بیشترین تکرار", "کدام کالا", "کدوم کالا", "تکراری ترین", "بیشتر تکرار")):
        rows = []
        for entry in catalog.values():
            rows.append({"key": entry["key"], "name": entry["name"],
                         "orders": len(entry["order_indices"]), "quantity": round(entry["quantity"], 4)})
        rows.sort(key=lambda x: (x["orders"], x["quantity"], x["name"]), reverse=True)
        top = rows[:5]
        evidence = _base_evidence(orders, "top_repeated_products")
        evidence["top_products"] = top
        if top:
            answer = "کالاهایی که در بیشترین تعداد سفارش تکرار شده‌اند:\n" + "\n".join(
                f"{row['name']}: در {row['orders']} سفارش، مجموع {_fmt(row['quantity'])} واحد" for row in top)
        else:
            answer = "در سفارش‌های موجود نام کالای قابل‌تحلیلی ثبت نشده است."
        return result("top_repeated_products", "top_products", evidence, answer)

    if any(word in q for word in ("چند سفارش", "تعداد سفارش", "تعداد خرید", "چند تا سفارش", "چند خرید")):
        evidence = _base_evidence(orders, "order_count")
        evidence["order_count"] = len(orders)
        answer = f"در دادهٔ در دسترس {len(orders)} سفارش بررسی شده است."
        return result("order_count", "order_count", evidence, answer)

    return {"status": "unsupported", "tool": "no_deterministic_tool_selected", "intent": "general_or_ambiguous",
            "matched_product": None,
            "evidence": {"orders_considered": len(orders), "available_product_names": len(catalog)},
            "direct_answer": None}


def _close(a: Any, b: Any) -> bool:
    x, y = _finite_number(a), _finite_number(b)
    return x is not None and y is not None and abs(x - y) <= max(0.01, abs(y) * 1e-8)


def _harness_validate(orders: list[dict[str, Any]], plan: dict[str, Any]) -> tuple[bool, list[str]]:
    """Recalculate key values independently before a local answer is trusted."""
    ev = plan.get("evidence") or {}
    tool = plan.get("tool")
    checks: list[str] = []
    if ev.get("orders_considered") != len(orders):
        return False, ["orders_considered_mismatch"]
    checks.append("dataset_count_matches")

    if tool == "total_spend":
        amounts = _known_amounts(orders)
        expected_total = round(sum(amounts), 2) if amounts else None
        actual_total = ev.get("sum_known_amounts_toman")
        total_matches = (expected_total is None and actual_total is None) or (expected_total is not None and _close(actual_total, expected_total))
        if ev.get("known_amounts_count") != len(amounts) or not total_matches:
            return False, checks + ["total_spend_recalculation_failed"]
        checks.append("total_spend_recalculated")
    elif tool in {"average_order_amount", "median_order_amount"}:
        amounts = _known_amounts(orders)
        expected = (sum(amounts) / len(amounts)) if tool == "average_order_amount" and amounts else (
            float(median(amounts)) if amounts else None)
        actual = ev.get("average_known_order_toman") if tool == "average_order_amount" else ev.get("median_known_order_toman")
        if ev.get("known_amounts_count") != len(amounts) or (expected is None and actual is not None) or (expected is not None and not _close(actual, expected)):
            return False, checks + ["order_statistic_recalculation_failed"]
        checks.append("order_statistic_recalculated")
    elif tool == "order_count":
        if ev.get("order_count") != len(orders):
            return False, checks + ["order_count_recalculation_failed"]
        checks.append("order_count_recalculated")
    elif tool in {"product_analysis", "product_line_spend", "product_price_history", "product_purchase_frequency", "product_summary"}:
        key = ev.get("product_key")
        found_orders: set[int] = set()
        quantity = priced_qty = unpriced_qty = spend = 0.0
        prices: list[float] = []
        for index, order in enumerate(orders):
            items = order.get("items", [])
            if not isinstance(items, list):
                continue
            for item in items:
                if not isinstance(item, dict) or normalize_text(item.get("name")) != key:
                    continue
                found_orders.add(index)
                qty = _quantity(item)
                quantity += qty
                price = _unit_price(item)
                if price is None:
                    unpriced_qty += qty
                else:
                    priced_qty += qty
                    spend += price * qty
                    prices.append(price)
        checks.extend(["product_exact_match", "product_counts_recalculated"])
        if len(found_orders) != ev.get("orders_with_product") or not _close(quantity, ev.get("quantity_total")):
            return False, checks + ["product_frequency_recalculation_failed"]
        if not _close(priced_qty, ev.get("priced_quantity")) or not _close(unpriced_qty, ev.get("unpriced_quantity")) or not _close(spend, ev.get("known_line_spend_toman")):
            return False, checks + ["product_spend_recalculation_failed"]
        if ev.get("price_observations") != len(prices):
            return False, checks + ["product_price_count_recalculation_failed"]
        actual_min = min(prices) if prices else None
        actual_max = max(prices) if prices else None
        if (actual_min is None and ev.get("min_unit_price_toman") is not None) or (actual_min is not None and not _close(actual_min, ev.get("min_unit_price_toman"))):
            return False, checks + ["product_min_price_recalculation_failed"]
        if (actual_max is None and ev.get("max_unit_price_toman") is not None) or (actual_max is not None and not _close(actual_max, ev.get("max_unit_price_toman"))):
            return False, checks + ["product_max_price_recalculation_failed"]
        checks.extend(["product_line_spend_recalculated", "product_price_bounds_recalculated"])
    elif tool == "top_repeated_products":
        actual: dict[str, dict[str, Any]] = {}
        for idx, order in enumerate(orders):
            seen: set[str] = set()
            for item in order.get("items", []) if isinstance(order.get("items", []), list) else []:
                if not isinstance(item, dict):
                    continue
                name = str(item.get("name") or "").strip()
                key = normalize_text(name)
                if not key or key in {normalize_text(x) for x in UNKNOWN_NAMES}:
                    continue
                row = actual.setdefault(key, {"key": key, "name": name, "orders": 0, "quantity": 0.0})
                row["quantity"] += _quantity(item)
                if key not in seen:
                    row["orders"] += 1
                    seen.add(key)
        recomputed = sorted(actual.values(), key=lambda x: (x["orders"], x["quantity"], x["name"]), reverse=True)[:5]
        reported = ev.get("top_products", [])
        if len(recomputed) != len(reported) or any(a["key"] != b.get("key") or a["orders"] != b.get("orders") or not _close(a["quantity"], b.get("quantity")) for a, b in zip(recomputed, reported)):
            return False, checks + ["top_products_recalculation_failed"]
        checks.append("top_products_recalculated")
    elif tool == "monthly_spend":
        actual_spend: Counter[str] = Counter()
        actual_orders: Counter[str] = Counter()
        actual_amount_counts: Counter[str] = Counter()
        for order in orders:
            month = _month_key(order.get("date"))
            if not month:
                continue
            actual_orders[month] += 1
            amount = _amount(order)
            if amount is not None:
                actual_spend[month] += amount
                actual_amount_counts[month] += 1
        reported = ev.get("monthly", [])
        expected_months = sorted(actual_orders)
        if [row.get("month") for row in reported] != expected_months:
            return False, checks + ["monthly_keys_recalculation_failed"]
        if any(row.get("orders") != actual_orders[row["month"]] or row.get("orders_with_amount") != actual_amount_counts[row["month"]] or
               (row.get("known_spend_toman") is None and actual_amount_counts[row["month"]] > 0) or
               (row.get("known_spend_toman") is not None and (actual_amount_counts[row["month"]] == 0 or not _close(row.get("known_spend_toman"), actual_spend[row["month"]])))
               for row in reported):
            return False, checks + ["monthly_spend_recalculation_failed"]
        checks.append("monthly_spend_recalculated")
    else:
        return False, checks + ["unknown_tool_rejected"]
    return True, checks


def run_analytics_agent(orders: list[dict[str, Any]], query: str, coverage: dict[str, Any] | None = None) -> dict[str, Any]:
    """Select a local analytics tool and only release its answer after harness checks pass."""
    safe_coverage = coverage if isinstance(coverage, dict) else {}
    plan = _build_plan(orders, query, safe_coverage)
    if plan.get("status") == "unsupported":
        plan["harness"] = {"passed": True, "checks": ["no_unsupported_direct_answer"]}
        return plan
    passed, checks = _harness_validate(orders, plan)
    plan["harness"] = {"passed": passed, "checks": checks}
    if passed:
        plan["status"] = "verified"
    else:
        plan["status"] = "harness_rejected"
        plan["direct_answer"] = None
        plan["rejection_reason"] = "محاسبات عامل از بررسی مستقل Harness عبور نکرد."
    return plan
