"""Safe adapter for BasketMind's three-question deterministic product core.

No network calls are made here. Recognized product questions are handled locally; unsupported
questions return None so the existing application path can continue. Before returning a result,
a separate verification pass recomputes dates, amounts, category totals, recurrence intervals and
the complete set of reorder suggestions from the raw normalized orders. The final answer text is
rendered from verified evidence, not copied blindly from a prior text response.
"""
from __future__ import annotations

import json
import os
import re
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal
from functools import lru_cache
from pathlib import Path
from statistics import median
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from basketmind_product_core import (
    BasketMindCore, CATEGORY_ALIASES, PERSIAN_MONTHS, PRODUCT_QUERY_STOPWORDS, _canonical_product, _status_is_eligible,
    fmt_number, gregorian_to_jalali, jalali_to_gregorian, normalize_text,
    parse_decimal, parse_order_date,
)

APP_DIR = Path(__file__).resolve().parent
DEFAULT_ALIAS_FILE = APP_DIR / "product_aliases.json"

# The oracle has its own small, readable classifier instead of calling the core's classifier.
# This intentionally prefers abstention over making up a category for an unknown product.
_ORACLE_CATEGORY_PHRASES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("جایگزین‌های گیاهی", ("شیر بادام", "شیر سویا", "شیر جو دوسر", "شیر نارگیل گیاهی", "ماست گیاهی")),
    ("لبنیات", ("شیر", "ماست", "پنیر", "دوغ", "کره", "خامه", "کشک", "سرشیر", "پنیر خامه ای", "ماست چکیده")),
    ("نان و غلات", ("نان سنگک", "نان بربری", "نان لواش", "نان تافتون", "نان", "باگت", "جو دوسر")),
    ("میوه و سبزیجات", ("سیب زمینی", "گوجه فرنگی", "خیار", "گوجه", "پیاز", "هویج", "سیب", "موز", "پرتقال", "لیمو", "کاهو", "سبزی")),
    ("گوشت و پروتئین", ("سینه مرغ", "مرغ", "گوشت گوسفند", "گوشت گوساله", "گوشت", "ماهی", "تخم مرغ", "تخممرغ")),
    ("مواد شوینده", ("مایع ظرفشویی", "پودر لباسشویی", "مایع لباسشویی", "دستمال کاغذی", "شامپو فرش", "شوینده")),
    ("نوشیدنی‌ها", ("نوشابه", "آب معدنی", "آبمیوه", "چای", "قهوه")),
    ("مواد غذایی خشک", ("برنج", "ماکارونی", "روغن", "رب گوجه", "عدس", "لوبیا", "نخود", "آرد", "شکر")),
)


def _tehran_today() -> date:
    try:
        return datetime.now(ZoneInfo("Asia/Tehran")).date()
    except (ZoneInfoNotFoundError, OSError):
        return date.today()


@lru_cache(maxsize=4)
def _load_aliases(path: Path = DEFAULT_ALIAS_FILE) -> dict[str, list[str]]:
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError("product_aliases.json is unreadable; local feature path halted") from exc
    if not isinstance(value, dict) or any(not isinstance(k, str) or not isinstance(v, list) for k, v in value.items()):
        raise RuntimeError("product_aliases.json must be an object of canonical product names to alias lists")
    if any(any(not isinstance(alias, str) for alias in aliases) for aliases in value.values()):
        raise RuntimeError("all product aliases must be strings")
    return value


def _same_decimal(actual: Any, expected: Decimal | None) -> bool:
    if expected is None:
        return actual is None
    try:
        return Decimal(str(actual)) == expected
    except Exception:
        return False


def _oracle_item_total(item: dict[str, Any]) -> tuple[Decimal | None, Decimal | None, bool]:
    """Independent line arithmetic: total, recorded unit price, and whether quantity was explicit."""
    unit = parse_decimal(item.get("unit_price_toman"))
    if unit is not None and unit < 0:
        unit = None
    line_total = parse_decimal(item.get("line_total_toman"))
    if line_total is not None and line_total < 0:
        line_total = None
    raw_quantity = item.get("quantity")
    quantity_known = raw_quantity not in (None, "") and parse_decimal(raw_quantity) is not None
    quantity = parse_decimal(raw_quantity) if quantity_known else None
    if line_total is None and unit is not None and quantity_known and quantity is not None and quantity >= 0:
        line_total = unit * quantity
    return line_total, unit, quantity_known


def _oracle_word_match(name: str, phrase: str) -> bool:
    normalized_name, normalized_phrase = normalize_text(name), normalize_text(phrase)
    if not normalized_name or not normalized_phrase:
        return False
    # Persian text has no whitespace between compound pieces in some product names, so support
    # normalized substring matching but keep longest-match and tie checks in the caller.
    return normalized_name == normalized_phrase or bool(re.search(
        rf"(?<!\w){re.escape(normalized_phrase)}(?!\w)", normalized_name, flags=re.UNICODE
    ))


def _oracle_category(item: dict[str, Any], name: str) -> str | None:
    explicit = item.get("category") or item.get("category_name") or item.get("category_path")
    if explicit:
        explicit_norm = normalize_text(str(explicit))
        for canonical, aliases in CATEGORY_ALIASES.items():
            if explicit_norm in {normalize_text(canonical), *(normalize_text(alias) for alias in aliases)}:
                return canonical
        return "__explicit_other__"
    matches: list[tuple[int, str]] = []
    name_norm = normalize_text(name)
    for category, phrases in _ORACLE_CATEGORY_PHRASES:
        for phrase in phrases:
            phrase_norm = normalize_text(phrase)
            if _oracle_word_match(name_norm, phrase_norm):
                matches.append((len(phrase_norm), category))
    if not matches:
        return None
    longest = max(length for length, _category in matches)
    winner_categories = {category for length, category in matches if length == longest}
    return next(iter(winner_categories)) if len(winner_categories) == 1 else None


def _independent_query_product_candidates(core: BasketMindCore, query: str) -> set[str]:
    """Resolve the product phrase independently from the engine's internal matcher.

    This is a conservative check, not a fuzzy scorer: exact titles/aliases and at least two shared
    descriptive tokens are accepted. Generic one-token requests intentionally remain ambiguous if
    several catalog entries contain that token.
    """
    q = normalize_text(query)
    query_tokens = [token for token in q.split() if token not in PRODUCT_QUERY_STOPWORDS and not token.isdigit()]
    qset = set(query_tokens)
    candidates: set[str] = set()
    for key, product in core.products.items():
        title = str(product.get("name") or "")
        normalized_title = normalize_text(title)
        variants = [title]
        for canonical, aliases in core.product_aliases.items():
            canonical_norm = normalize_text(canonical)
            if canonical_norm == key or _oracle_word_match(normalized_title, canonical_norm):
                variants.extend(aliases)
        exact = any(v and re.search(r"(?<!\w)" + re.escape(normalize_text(v)) + r"(?!\w)", q)
                    for v in variants if normalize_text(v))
        if exact:
            candidates.add(key)
            continue
        title_tokens = {token for token in normalized_title.split()
                        if token not in PRODUCT_QUERY_STOPWORDS and not token.isdigit()}
        overlap = len(title_tokens & qset)
        required = 1 if len(query_tokens) == 1 else 2
        if query_tokens and overlap >= required:
            candidates.add(key)
    # Shadow a shorter exact product title when a longer exact title encloses it in the query.
    # This only affects direct textual containment; it does not resolve token-only ambiguity.
    direct_spans: dict[str, list[tuple[int, int]]] = defaultdict(list)
    for key, product in core.products.items():
        title = normalize_text(str(product.get("name") or ""))
        if title:
            matches = [(m.start(), m.end()) for m in re.finditer(r"(?<!\w)" + re.escape(title) + r"(?!\w)", q)]
            if matches:
                direct_spans[key].extend(matches)
    direct_keys = set(direct_spans)
    for short_key, short_spans in direct_spans.items():
        for long_key, long_spans in direct_spans.items():
            if short_key == long_key:
                continue
            if any(ls <= ss and le >= se and (le-ls) > (se-ss)
                   for ss, se in short_spans for ls, le in long_spans):
                direct_keys.discard(short_key)
                candidates.discard(short_key)
                break
    if direct_keys:
        # Still retain token-only products if query names multiple items; the core should clarify.
        candidates |= direct_keys
    return candidates


def _independent_query_category_candidates(query: str) -> set[str]:
    """Find explicit category mentions independently; multiple categories must not collapse to one."""
    q = normalize_text(query)
    hits: list[tuple[int, int, str, int]] = []
    for canonical, aliases in CATEGORY_ALIASES.items():
        for phrase in (canonical, *aliases):
            phrase_norm = normalize_text(phrase)
            if not phrase_norm:
                continue
            for match in re.finditer(r"(?<!\w)" + re.escape(phrase_norm) + r"(?!\w)", q, flags=re.UNICODE):
                hits.append((match.start(), match.end(), canonical, len(phrase_norm)))
    # Remove shorter alias hits nested inside a longer explicit category phrase.
    surviving: list[tuple[int, int, str, int]] = []
    for hit in hits:
        start, end, category, length = hit
        nested = any(
            (other_start <= start and other_end >= end and other_length > length)
            for other_start, other_end, _other_category, other_length in hits
        )
        if not nested:
            surviving.append(hit)
    return {category for _start, _end, category, _length in surviving}


def _expected_closed_month_windows(as_of: date, calendar: str) -> tuple[tuple[date, date], tuple[date, date]]:
    """Calculate the two immediately preceding complete calendar months independently of core."""
    calendar = calendar.lower()
    if calendar == "jalali":
        jy, jm, _jd = gregorian_to_jalali(as_of.year, as_of.month, as_of.day)
        def previous(y: int, m: int) -> tuple[int, int]:
            return (y - 1, 12) if m == 1 else (y, m - 1)
        newer_y, newer_m = previous(jy, jm)
        older_y, older_m = previous(newer_y, newer_m)
        def bounds(y: int, m: int) -> tuple[date, date]:
            start = jalali_to_gregorian(y, m, 1)
            if m <= 6:
                end_day = 31
            elif m <= 11:
                end_day = 30
            else:
                try:
                    jalali_to_gregorian(y, m, 30)
                    end_day = 30
                except ValueError:
                    end_day = 29
            return start, jalali_to_gregorian(y, m, end_day)
        return bounds(newer_y, newer_m), bounds(older_y, older_m)
    if calendar != "gregorian":
        raise ValueError(f"unsupported calendar: {calendar}")
    def previous_g(y: int, m: int) -> tuple[int, int]:
        return (y - 1, 12) if m == 1 else (y, m - 1)
    ny, nm = previous_g(as_of.year, as_of.month)
    oy, om = previous_g(ny, nm)
    return ((date(ny, nm, 1), date(ny, nm, _month_days(ny, nm))),
            (date(oy, om, 1), date(oy, om, _month_days(oy, om))))


def _oracle_month_label(start: date, calendar: str) -> str:
    """Independently label a verified month boundary; do not trust a label in core output."""
    digit_map = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
    if calendar.lower() == "jalali":
        year, month, day = gregorian_to_jalali(start.year, start.month, start.day)
        if day != 1 or not 1 <= month <= 12:
            raise ValueError("month start is not a valid Jalali month boundary")
        return f"{PERSIAN_MONTHS[month - 1]} {year}".translate(digit_map)
    if calendar.lower() == "gregorian":
        return f"{start.year:04d}/{start.month:02d}".translate(digit_map)
    raise ValueError(f"unsupported calendar: {calendar}")


def _month_days(year: int, month: int) -> int:
    from calendar import monthrange
    return monthrange(year, month)[1]


def _verify_last_purchase(core: BasketMindCore, result: dict[str, Any], query: str | None = None) -> tuple[bool, list[str]]:
    evidence = result.get("evidence", {})
    product_name = evidence.get("product")
    if not isinstance(product_name, str) or not product_name:
        return False, ["last_purchase_product_missing"]
    wanted_key, _ = _canonical_product(product_name, core.product_aliases)
    if query is not None:
        query_candidates = _independent_query_product_candidates(core, query)
        if len(query_candidates) != 1 or wanted_key not in query_candidates:
            return False, ["product_selection_does_not_match_unique_query_candidate"]
    matching: list[tuple[date, dict[str, Any]]] = []
    for order in core.orders:
        day = parse_order_date(order.get("date") or order.get("date_text"))
        if day is None or not _status_is_eligible(order.get("status")):
            continue
        items = order.get("items", [])
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or item.get("product_name") or "").strip()
            key, _ = _canonical_product(name, core.product_aliases)
            if key == wanted_key:
                matching.append((day, item))
    if not matching:
        return False, ["last_purchase_source_record_missing"]
    newest = max(day for day, _ in matching)
    if evidence.get("last_purchase_date") != newest.isoformat():
        return False, ["last_purchase_date_recalculation_failed"]
    latest_items = [item for day, item in matching if day == newest]
    totals = [_oracle_item_total(item) for item in latest_items]
    expected_total = (sum((row[0] for row in totals if row[0] is not None), Decimal("0"))
                      if all(row[0] is not None for row in totals) else None)
    quantities_known = all(row[2] for row in totals)
    q_values = [parse_decimal(item.get("quantity")) for item in latest_items]
    expected_qty = (sum((q for q in q_values if q is not None), Decimal("0"))
                    if quantities_known else None)
    if expected_total is not None and not _same_decimal(evidence.get("line_total_toman"), expected_total):
        return False, ["last_purchase_line_total_recalculation_failed"]
    if expected_total is None and evidence.get("line_total_toman") is not None:
        return False, ["last_purchase_unknown_total_was_invented"]
    all_unit_prices_known = all(row[1] is not None for row in totals)
    expected_unit: Decimal | None = None
    if all_unit_prices_known:
        if expected_total is not None and expected_qty not in (None, Decimal("0")):
            expected_unit = expected_total / expected_qty
        elif len(totals) == 1:
            expected_unit = totals[0][1]
    if not _same_decimal(evidence.get("unit_price_toman"), expected_unit):
        return False, ["last_purchase_unit_price_recalculation_failed"]
    return True, ["last_purchase_date_recomputed", "last_purchase_amount_recomputed"]


def _verify_category_comparison(core: BasketMindCore, result: dict[str, Any], as_of: date,
                                query: str | None = None) -> tuple[bool, list[str]]:
    evidence = result.get("evidence", {})
    category = evidence.get("category")
    if not isinstance(category, str):
        return False, ["category_missing"]
    if query is not None:
        query_categories = _independent_query_category_candidates(query)
        if len(query_categories) != 1 or category not in query_categories:
            return False, ["category_selection_does_not_match_unique_query_category"]
    try:
        expected_windows = _expected_closed_month_windows(as_of, str(evidence.get("calendar", core.calendar)))
    except (ValueError, TypeError):
        return False, ["calendar_invalid"]
    periods: list[Decimal] = []
    for name, expected_window in zip(("newer_month", "older_month"), expected_windows):
        item = evidence.get(name)
        if not isinstance(item, dict):
            return False, ["month_evidence_missing"]
        try:
            start, end = date.fromisoformat(item["start"]), date.fromisoformat(item["end"])
        except (KeyError, ValueError, TypeError):
            return False, ["month_boundary_invalid"]
        if (start, end) != expected_window:
            return False, [f"{name}_does_not_match_expected_calendar_month"]
        expected_label = _oracle_month_label(start, str(evidence.get("calendar", core.calendar)))
        if item.get("label") != expected_label:
            return False, [f"{name}_label_does_not_match_calendar_boundary"]
        spend = Decimal("0")
        missing_amounts = 0
        unknown_categories = 0
        for order in core.orders:
            od = parse_order_date(order.get("date") or order.get("date_text"))
            if od is None or not (start <= od <= end) or not _status_is_eligible(order.get("status")):
                continue
            raw_items = order.get("items", [])
            if not isinstance(raw_items, list):
                continue
            for raw_item in raw_items:
                if not isinstance(raw_item, dict):
                    continue
                pname = str(raw_item.get("name") or raw_item.get("product_name") or "").strip()
                item_category = _oracle_category(raw_item, pname)
                if item_category is None:
                    unknown_categories += 1
                    continue
                if item_category != category:
                    continue
                line_total, _unit, _quantity_known = _oracle_item_total(raw_item)
                if line_total is None:
                    missing_amounts += 1
                else:
                    spend += line_total
        if not _same_decimal(item.get("known_spend_toman"), spend):
            return False, [f"{name}_category_spend_recalculation_failed"]
        if item.get("missing_price_lines") != missing_amounts:
            return False, [f"{name}_missing_price_count_failed"]
        if item.get("unknown_category_lines") != unknown_categories:
            return False, [f"{name}_unknown_category_count_failed"]
        periods.append(spend)
    change = periods[0] - periods[1]
    if not _same_decimal(evidence.get("change_toman"), change):
        return False, ["category_change_recalculation_failed"]
    pct = change / periods[1] * Decimal("100") if periods[1] > 0 else None
    if not _same_decimal(evidence.get("change_percent"), pct):
        return False, ["category_percentage_recalculation_failed"]
    return True, ["month_boundaries_recomputed", "category_spend_recomputed_from_raw_lines", "change_recomputed"]


def _verify_reorder(core: BasketMindCore, result: dict[str, Any], as_of: date) -> tuple[bool, list[str]]:
    evidence = result.get("evidence", {})
    suggestions = evidence.get("suggestions")
    if not isinstance(suggestions, list):
        return False, ["reorder_suggestions_missing"]
    if evidence.get("as_of_date") != as_of.isoformat():
        return False, ["reorder_as_of_date_mismatch"]
    minimum_events = evidence.get("minimum_purchase_events", 3)
    # This is a product policy, not a caller-tunable output field. The Harness fixes it to three.
    if isinstance(minimum_events, bool) or minimum_events != 3:
        return False, ["reorder_minimum_events_policy_mismatch"]
    events: dict[str, set[date]] = defaultdict(set)
    display: dict[str, str] = {}
    for order in core.orders:
        day = parse_order_date(order.get("date") or order.get("date_text"))
        if day is None or not _status_is_eligible(order.get("status")):
            continue
        items = order.get("items", [])
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            raw_name = str(item.get("name") or item.get("product_name") or "").strip()
            key, canonical = _canonical_product(raw_name, core.product_aliases)
            if key:
                events[key].add(day)
                display[key] = canonical
    expected: dict[str, dict[str, Any]] = {}
    approaching_ratio = Decimal("0.75")
    for key, day_set in events.items():
        days = sorted(day_set)
        if len(days) < minimum_events:
            continue
        intervals = [(days[i] - days[i - 1]).days for i in range(1, len(days)) if (days[i] - days[i - 1]).days > 0]
        if len(intervals) < 2:
            continue
        median_gap = Decimal(str(median(intervals)))
        if median_gap <= 0:
            continue
        elapsed = (as_of - days[-1]).days
        ratio = Decimal(elapsed) / median_gap
        if ratio < approaching_ratio:
            continue
        state = "due" if Decimal(elapsed) >= median_gap else "approaching"
        expected[key] = {
            "product": display[key], "state": state, "last_purchase_date": days[-1].isoformat(),
            "days_since_last_purchase": elapsed, "median_repurchase_interval_days": int(median_gap),
            "elapsed_to_interval_ratio": str(ratio.quantize(Decimal("0.01"))),
            "observed_purchase_events": len(days),
        }
    expected_rows = sorted(expected.values(), key=lambda row: (
        row["state"] != "due", -float(row["elapsed_to_interval_ratio"]), row["product"]
    ))[:8]
    actual_by_key: dict[str, dict[str, Any]] = {}
    for row in suggestions:
        if not isinstance(row, dict):
            return False, ["reorder_row_invalid"]
        key, _ = _canonical_product(str(row.get("product") or ""), core.product_aliases)
        if not key or key in actual_by_key:
            return False, ["reorder_product_missing_or_duplicated"]
        actual_by_key[key] = row
    expected_by_key = {_canonical_product(str(row["product"]), core.product_aliases)[0]: row for row in expected_rows}
    if set(actual_by_key) != set(expected_by_key):
        return False, ["reorder_suggestion_set_does_not_match_independent_reference"]
    for key, expected_row in expected_by_key.items():
        actual = actual_by_key[key]
        for field in ("state", "last_purchase_date", "days_since_last_purchase", "median_repurchase_interval_days", "observed_purchase_events"):
            if actual.get(field) != expected_row[field]:
                return False, [f"reorder_{field}_recalculation_failed"]
        if actual.get("elapsed_to_interval_ratio") != expected_row["elapsed_to_interval_ratio"]:
            return False, ["reorder_ratio_recalculation_failed"]
        expected_display = _display_date_from_iso(expected_row["last_purchase_date"], core.calendar)
        if actual.get("last_purchase_date_display") != expected_display:
            return False, ["reorder_display_date_recalculation_failed"]
    if "موجودی واقعی خانه" not in result.get("answer", ""):
        return False, ["reorder_stock_disclaimer_missing"]
    return True, ["reorder_events_recomputed", "complete_suggestion_set_recomputed", "stock_limit_disclosed"]


def _display_date_from_iso(iso_date: str, calendar: str) -> str:
    day = date.fromisoformat(iso_date)
    if calendar.lower() == "jalali":
        jy, jm, jd = gregorian_to_jalali(day.year, day.month, day.day)
        return f"{jy:04d}/{jm:02d}/{jd:02d}".translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))
    return day.isoformat()


def verify_product_result(core: BasketMindCore, result: dict[str, Any], as_of: date, query: str | None = None) -> dict[str, Any]:
    """Independent evidence checks before any numeric response reaches the UI."""
    status = result.get("status")
    intent = result.get("intent")
    if status in {"clarification_required", "data_insufficient"}:
        answer = str(result.get("answer") or "")
        if any(unit in answer for unit in (" تومان", "٪")):
            return {"passed": False, "checks": ["abstention_contains_numeric_claim"]}
        return {"passed": True, "checks": ["safe_clarification_or_abstention"]}
    if intent == "last_purchase":
        passed, checks = _verify_last_purchase(core, result, query)
    elif intent == "category_month_comparison":
        if result.get("evidence", {}).get("calendar") != core.calendar:
            return {"passed": False, "checks": ["calendar_does_not_match_configured_calendar"]}
        passed, checks = _verify_category_comparison(core, result, as_of, query=query)
    elif intent == "reorder_suggestions":
        passed, checks = _verify_reorder(core, result, as_of)
    else:
        return {"passed": False, "checks": ["unknown_product_core_intent"]}
    return {"passed": passed, "checks": checks}


def _verified_answer(core: BasketMindCore, result: dict[str, Any]) -> str:
    """Render verified facts afresh so a corrupted free-text draft cannot override evidence."""
    status, intent = result.get("status"), result.get("intent")
    evidence = result.get("evidence") or {}
    if status in {"clarification_required", "data_insufficient"}:
        return str(result.get("answer") or "برای پاسخ دقیق‌تر، لطفاً سؤال را روشن‌تر کن.")
    if intent == "last_purchase":
        product = str(evidence["product"])
        display_day = _display_date_from_iso(str(evidence["last_purchase_date"]), core.calendar)
        unit, total = parse_decimal(evidence.get("unit_price_toman")), parse_decimal(evidence.get("line_total_toman"))
        answer = f"آخرین خرید ثبت‌شدهٔ «{product}» در {display_day} بوده است. "
        if unit is not None and total is not None:
            answer += f"قیمت واحد ثبت‌شده {fmt_number(unit)} تومان و مبلغ قلم/اقلام {fmt_number(total)} تومان است."
        elif unit is not None:
            answer += f"قیمت واحد ثبت‌شده {fmt_number(unit)} تومان است؛ مبلغ کل قلم به‌دلیل ناقص بودن تعداد یا قیمت ردیف‌ها قابل تأیید نیست."
        elif total is not None:
            answer += f"مبلغ قلم/اقلام ثبت‌شده {fmt_number(total)} تومان است؛ قیمت واحد یکتا قابل استخراج نیست."
        else:
            answer += "قیمت قلم در دادهٔ موجود ثبت نشده است؛ مبلغ کل سفارش را به این کالا نسبت نمی‌دهم."
        return answer + _coverage_suffix(result)
    if intent == "category_month_comparison":
        newer, older = evidence["newer_month"], evidence["older_month"]
        change = Decimal(str(evidence["change_toman"]))
        pct = parse_decimal(evidence.get("change_percent"))
        direction = "افزایش" if change > 0 else "کاهش" if change < 0 else "بدون تغییر"
        pct_text = f" ({fmt_number(pct)}٪)" if pct is not None else " (درصد تغییر به‌دلیل صفر/نامشخص بودن مبنای ماه قبل قابل محاسبه نیست)"
        answer = (f"هزینهٔ ثبت‌شدهٔ دستهٔ «{evidence['category']}» در {newer['label']}: "
                  f"{fmt_number(Decimal(str(newer['known_spend_toman'])))} تومان؛ در {older['label']}: "
                  f"{fmt_number(Decimal(str(older['known_spend_toman'])))} تومان. "
                  f"{direction} نسبت به ماه قبل‌تر: {fmt_number(abs(change))} تومان{pct_text}.")
        notices = []
        if any(int(evidence[name].get("missing_price_lines", 0)) for name in ("newer_month", "older_month")):
            notices.append("برخی اقلام قیمت قابل‌محاسبه نداشتند؛ جمع اعلام‌شده فقط شامل مبالغ معلوم است.")
        if any(int(evidence[name].get("unknown_category_lines", 0)) for name in ("newer_month", "older_month")):
            notices.append("طبقه‌بندی برخی اقلام نامشخص است؛ جمع دسته ممکن است ناقص باشد.")
        if any(int(evidence[name].get("undated_orders", 0)) for name in ("newer_month", "older_month")):
            notices.append("تاریخ بخشی از سفارش‌ها قابل‌تفسیر نبود.")
        if result.get("warnings"):
            notices.append("کامل‌بودن همگام‌سازی تاریخچه تأیید نشده است.")
        if notices:
            answer += "\nمحدودیت داده: " + " ".join(dict.fromkeys(notices))
        return answer
    if intent == "reorder_suggestions":
        rows = evidence.get("suggestions", [])
        if not rows:
            answer = "از تاریخچهٔ موجود، کالای کافی با حداقل سه نوبت خرید و الگوی زمانی قابل‌محاسبه پیدا نشد."
        else:
            lines = []
            for row in rows:
                state_text = "احتمالاً زمان خرید مجدد رسیده" if row["state"] == "due" else "به بازهٔ معمول خرید نزدیک شده"
                day = _display_date_from_iso(row["last_purchase_date"], core.calendar)
                lines.append(f"{row['product']}: {state_text}؛ آخرین خرید {day}، "
                             f"{row['days_since_last_purchase']} روز گذشته؛ فاصلهٔ معمول مشاهده‌شده حدود "
                             f"{row['median_repurchase_interval_days']} روز است.")
            answer = "پیشنهادهای احتمالی بر اساس تکرار خریدهای ثبت‌شده:\n" + "\n".join(lines)
        answer += "\nاین فهرست از الگوی خرید ساخته شده، نه از موجودی واقعی خانه؛ قبل از خرید بررسی کن."
        return answer + _coverage_suffix(result)
    raise ValueError(f"cannot render answer for verified intent {intent!r}")


def _coverage_suffix(result: dict[str, Any]) -> str:
    warnings = list(result.get("warnings") or [])
    if not warnings:
        return ""
    safe = []
    for warning in warnings:
        w = str(warning)
        if "همگام" in w or "کامل بودن" in w or "کامل‌بودن" in w:
            safe.append("کامل‌بودن همگام‌سازی تاریخچه تأیید نشده است.")
        elif "تاریخ" in w:
            safe.append("تاریخ بخشی از سفارش‌ها قابل‌تفسیر نبود.")
        elif "وضعیت" in w:
            safe.append("وضعیت بعضی سفارش‌ها ثبت نشده است.")
        elif "قیمت" in w:
            safe.append("اطلاعات قیمت بخشی از اقلام ناقص است.")
    return "\nمحدودیت داده: " + " ".join(dict.fromkeys(safe)) if safe else ""


def try_answer_product_question(orders: list[dict[str, Any]], query: str,
                                coverage: dict[str, Any] | None = None,
                                as_of_date: date | None = None) -> dict[str, Any] | None:
    """Return a verified local response for the three features, else None for normal routing."""
    aliases = _load_aliases()
    calendar = os.environ.get("BASKETMIND_CALENDAR", "jalali").strip().lower()
    as_of = as_of_date or _tehran_today()
    core = BasketMindCore(orders, coverage=coverage, product_aliases=aliases, calendar=calendar)
    result = core.answer_question(query, as_of_date=as_of)
    if result.get("status") == "unsupported":
        return None
    # If the user explicitly named more than one spend category, ask instead of letting the
    # core's longest-alias rule silently choose only one of them.
    if result.get("intent") == "category_month_comparison":
        named_categories = _independent_query_category_candidates(query)
        if len(named_categories) > 1:
            return {
                "status": "clarification_required", "tool": "basketmind_product_core",
                "intent": "category_month_comparison", "matched_product": None, "evidence": {},
                "direct_answer": "در سؤال بیش از یک دستهٔ خرید آمده است. لطفاً یک دسته را مشخص کن تا جمع و تغییر هزینه را اشتباه محاسبه نکنم.",
                "harness": {"passed": True, "checks": ["multiple_categories_require_clarification"]},
                "product_core_status": "clarification_required", "warnings": [],
                "llm_called": False, "external_data_sent": False,
            }
    harness = verify_product_result(core, result, as_of, query=query)
    if not harness["passed"]:
        return {
            "status": "harness_rejected", "tool": "basketmind_product_core", "intent": result.get("intent"),
            "matched_product": (result.get("evidence") or {}).get("product"), "evidence": {},
            "direct_answer": "برای جلوگیری از پاسخ اشتباه، نتیجهٔ محلی از کنترل مستقل عبور نکرد؛ در این نوبت پاسخ عددی نمی‌دهم.",
            "harness": harness, "product_core_status": result.get("status"),
        }
    try:
        answer = _verified_answer(core, result)
    except Exception:
        return {
            "status": "harness_rejected", "tool": "basketmind_product_core", "intent": result.get("intent"),
            "matched_product": (result.get("evidence") or {}).get("product"), "evidence": {},
            "direct_answer": "برای جلوگیری از ارائهٔ اطلاعات ناسازگار، نتوانستم پاسخ را به‌طور امن بسازم.",
            "harness": {"passed": False, "checks": ["verified_answer_render_failed"]},
            "product_core_status": result.get("status"),
        }
    return {
        "status": "verified", "tool": "basketmind_product_core", "intent": result.get("intent"),
        "matched_product": (result.get("evidence") or {}).get("product"),
        "evidence": result.get("evidence", {}), "direct_answer": answer,
        "harness": harness, "product_core_status": result.get("status"),
        "warnings": list(result.get("warnings") or []),
        "llm_called": False, "external_data_sent": False,
    }
