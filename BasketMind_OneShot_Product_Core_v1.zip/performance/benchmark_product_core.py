#!/usr/bin/env python3
"""Synthetic-only latency benchmark for the product core + independent Harness.

Measures one complete question call, including order indexing, local calculation, and the
independent verification pass. It does not benchmark SQLite, Okala, network, or OpenRouter.
"""
from __future__ import annotations

import csv
import json
import statistics
import sys
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from basketmind_product_adapter import try_answer_product_question  # noqa: E402

PRODUCTS = [
    ("شیر", "لبنیات", 65000),
    ("شیر بادام", "جایگزین‌های گیاهی", 98000),
    ("ماست", "لبنیات", 38000),
    ("پنیر", "لبنیات", 128000),
    ("برنج", "مواد غذایی خشک", 90000),
    ("دستمال کاغذی", "مواد شوینده", 45000),
    ("مایع ظرفشویی", "مواد شوینده", 72000),
    ("نان سنگک", "نان و غلات", 30000),
    ("موز", "میوه و سبزیجات", 55000),
    ("مرغ", "گوشت و پروتئین", 185000),
]
QUESTIONS = {
    "last_purchase": "آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟",
    "category_comparison": "هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟",
    "reorder_suggestions": "بر اساس خریدهای قبلی چه چیزهایی را دوباره بخرم؟",
}


def build_orders(count: int) -> list[dict]:
    start = date(2018, 1, 1)
    orders = []
    for i in range(count):
        day = start + timedelta(days=i)
        indexes = (i % len(PRODUCTS), (i * 3 + 2) % len(PRODUCTS), (i * 7 + 5) % len(PRODUCTS))
        items = []
        for j, index in enumerate(indexes):
            name, category, base = PRODUCTS[index]
            price = base + ((i * 13 + j * 7) % 9000)
            qty = 1 + ((i + j) % 2)
            items.append({"name": name, "category": category, "quantity": qty,
                          "unit_price_toman": price})
        order_total = sum(item["unit_price_toman"] * item["quantity"] for item in items)
        orders.append({"date": day.isoformat() + "T12:00:00", "status": "لغو شده" if i % 113 == 0 else "تحویل شده",
                       "amount_toman": order_total, "items": items})
    return orders


def percentile(values: list[float], p: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    position = (len(ordered) - 1) * p
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    frac = position - lower
    return ordered[lower] * (1 - frac) + ordered[upper] * frac


def benchmark(count: int, repeats: int = 9) -> list[dict]:
    orders = build_orders(count)
    as_of = date.fromisoformat(orders[-1]["date"][:10]) + timedelta(days=3)
    coverage = {"complete_sync": True, "scope": "synthetic benchmark", "orders_reviewed": count}
    rows = []
    for intent, query in QUESTIONS.items():
        # Warm-up imports/caches before the measured runs.
        warm = try_answer_product_question(orders, query, coverage, as_of)
        if warm is None or not warm.get("harness", {}).get("passed"):
            raise RuntimeError(f"Synthetic benchmark case failed before timing: n={count}, intent={intent}, result={warm}")
        samples = []
        for _ in range(repeats):
            start_ns = time.perf_counter_ns()
            result = try_answer_product_question(orders, query, coverage, as_of)
            elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000
            if result is None or not result.get("harness", {}).get("passed"):
                raise RuntimeError(f"Harness rejected benchmark case: n={count}, intent={intent}, result={result}")
            samples.append(elapsed_ms)
        rows.append({
            "orders": count,
            "items": sum(len(o["items"]) for o in orders),
            "intent": intent,
            "repeats": repeats,
            "status": "passed",
            "p50_ms": round(statistics.median(samples), 3),
            "p95_ms": round(percentile(samples, 0.95), 3),
            "min_ms": round(min(samples), 3),
            "max_ms": round(max(samples), 3),
            "network_calls": 0,
            "llm_calls": 0,
            "dataset": "synthetic_only",
        })
    return rows


def main() -> int:
    results = []
    for count in (100, 1000, 3000):
        results.extend(benchmark(count))
    out = ROOT / "performance" / "results"
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / "product_core_latency.csv"
    json_path = out / "product_core_latency.json"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)
    json_path.write_text(json.dumps({"generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                                    "synthetic_only": True, "python_version": sys.version, "platform": sys.platform,
                                    "results": results}, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Synthetic-only Product Core + Harness latency benchmark")
    for row in results:
        print(f"orders={row['orders']:4d} items={row['items']:5d} intent={row['intent']:22s} p50={row['p50_ms']:8.3f} ms p95={row['p95_ms']:8.3f} ms status={row['status']}")
    print(f"\nCSV: {csv_path}\nJSON: {json_path}")
    print("These figures exclude database loading, Okala/network latency, and OpenRouter; do not interpret them as end-to-end latency.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
