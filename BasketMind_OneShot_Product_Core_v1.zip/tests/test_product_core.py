from datetime import date
from decimal import Decimal
import unittest

from basketmind_product_core import (
    BasketMindCore, fmt_number, gregorian_to_jalali, jalali_to_gregorian,
    normalize_text, parse_order_date,
)
from examples.sample_orders import build_sample_orders


class CalendarTests(unittest.TestCase):
    def test_well_known_gregorian_to_jalali_examples(self):
        self.assertEqual(gregorian_to_jalali(2016, 4, 11), (1395, 1, 23))
        self.assertEqual(gregorian_to_jalali(2026, 3, 21), (1405, 1, 1))
        self.assertEqual(gregorian_to_jalali(2026, 10, 24), (1405, 8, 2))

    def test_jalali_round_trip_and_parse_persian_digits(self):
        self.assertEqual(jalali_to_gregorian(1405, 6, 1), date(2026, 8, 23))
        self.assertEqual(parse_order_date("۱۴۰۵/۰۶/۰۱"), date(2026, 8, 23))
        self.assertEqual(parse_order_date("2026-10-15T10:00:00"), date(2026, 10, 15))

    def test_invalid_jalali_day_is_rejected(self):
        self.assertIsNone(parse_order_date("۱۴۰۵/۰۶/۳۲"))

    def test_money_format_uses_persian_digits(self):
        self.assertEqual(fmt_number(Decimal("471000")), "۴۷۱٬۰۰۰")


class UserQuestionTests(unittest.TestCase):
    def setUp(self):
        self.orders = build_sample_orders()
        self.core = BasketMindCore(self.orders, coverage={"complete_sync": True, "scope": "synthetic fixture"})
        self.as_of = date(2026, 10, 24)

    def test_question_one_last_almond_milk_and_price(self):
        result = self.core.answer_question("آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟", as_of_date=self.as_of)
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["intent"], "last_purchase")
        self.assertEqual(result["evidence"]["product"], "شیر بادام")
        self.assertEqual(result["evidence"]["last_purchase_date"], "2026-10-15")
        self.assertEqual(result["evidence"]["unit_price_toman"], "100000")
        self.assertIn("۱۴۰۵/۰۷/۲۳", result["answer"])

    def test_product_resolution_never_confuses_milk_with_almond_milk(self):
        result = self.core.last_purchase("آخرین خرید شیر بادام")
        self.assertEqual(result["evidence"]["product"], "شیر بادام")
        self.assertNotEqual(result["evidence"]["product"], "شیر")

    def test_short_phrase_matches_verbose_store_title_without_matching_wrong_milk(self):
        orders = [{"date": "2026-10-15", "status": "تحویل شده", "items": [
            {"name": "شیر بادام بدون شکر کاله ۱ لیتری", "quantity": 1, "unit_price_toman": 98000},
            {"name": "شیر کم چرب پگاه ۱ لیتری", "quantity": 1, "unit_price_toman": 65000},
            {"name": "شیر پرچرب میهن ۱ لیتری", "quantity": 1, "unit_price_toman": 62000},
        ]}]
        core = BasketMindCore(orders, coverage={"complete_sync": True})
        result = core.last_purchase("آخرین بار شیر بادام را کی خریدم؟")
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["evidence"]["product"], "شیر بادام بدون شکر کاله ۱ لیتری")
        self.assertEqual(result["evidence"]["unit_price_toman"], "98000")

    def test_generic_milk_phrase_with_multiple_variants_requires_clarification(self):
        orders = [{"date": "2026-10-15", "status": "تحویل شده", "items": [
            {"name": "شیر بادام بدون شکر کاله ۱ لیتری", "quantity": 1, "unit_price_toman": 98000},
            {"name": "شیر کم چرب پگاه ۱ لیتری", "quantity": 1, "unit_price_toman": 65000},
            {"name": "شیر پرچرب میهن ۱ لیتری", "quantity": 1, "unit_price_toman": 62000},
        ]}]
        core = BasketMindCore(orders, coverage={"complete_sync": True})
        result = core.last_purchase("آخرین بار شیر را کی خریدم؟")
        self.assertEqual(result["status"], "clarification_required")
        self.assertGreaterEqual(len(result["evidence"]["candidate_products"]), 3)

    def test_multiple_product_mentions_require_clarification(self):
        result = self.core.last_purchase("آخرین بار شیر و پنیر را کی خریدم؟")
        self.assertEqual(result["status"], "clarification_required")
        self.assertIn("شیر", result["evidence"]["candidate_products"])
        self.assertIn("پنیر", result["evidence"]["candidate_products"])

    def test_missing_unit_price_does_not_invent_price_from_order_total(self):
        orders = [{"date": "2026-10-01", "status": "تحویل شده", "amount_toman": 900000,
                   "items": [{"name": "برنج", "quantity": 2}]}]
        core = BasketMindCore(orders, coverage={"complete_sync": True})
        result = core.last_purchase("برنج")
        self.assertEqual(result["status"], "partial")
        self.assertIsNone(result["evidence"]["unit_price_toman"])
        self.assertIsNone(result["evidence"]["line_total_toman"])
        self.assertIn("قیمت قلم در داده موجود نیست", result["answer"])

    def test_cancelled_purchase_does_not_override_last_purchase(self):
        orders = [
            {"date": "2026-10-01", "status": "تحویل شده", "items": [{"name": "نان", "quantity": 1, "unit_price_toman": 20000}]},
            {"date": "2026-10-12", "status": "لغو شده", "items": [{"name": "نان", "quantity": 9, "unit_price_toman": 90000}]},
        ]
        result = BasketMindCore(orders, coverage={"complete_sync": True}).last_purchase("نان")
        self.assertEqual(result["evidence"]["last_purchase_date"], "2026-10-01")

    def test_question_two_monthly_category_comparison(self):
        result = self.core.answer_question("هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟", as_of_date=self.as_of)
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["intent"], "category_month_comparison")
        self.assertEqual(result["evidence"]["newer_month"]["known_spend_toman"], "374000")
        self.assertEqual(result["evidence"]["older_month"]["known_spend_toman"], "845000")
        self.assertEqual(result["evidence"]["change_toman"], "-471000")
        self.assertEqual(result["evidence"]["change_percent"], str(Decimal("-471000") / Decimal("845000") * Decimal("100")))

    def test_order_total_is_not_wrongly_allocated_to_dairy(self):
        orders = [{"date": "2026-10-01", "status": "تحویل شده", "amount_toman": 999999,
                   "items": [{"name": "شیر", "quantity": 1, "unit_price_toman": 25000},
                             {"name": "برنج", "quantity": 1, "unit_price_toman": 50000}]}]
        core = BasketMindCore(orders, coverage={"complete_sync": True}, calendar="gregorian")
        result = core.compare_category_months("لبنیات", as_of_date=date(2026, 11, 2))
        # Oct is the comparison month, Sep is older. Use the explicit monthly output and ensure order total was not used.
        self.assertEqual(result["evidence"]["newer_month"]["known_spend_toman"], "25000")
        self.assertNotEqual(result["evidence"]["newer_month"]["known_spend_toman"], "999999")

    def test_plant_milk_is_not_classified_as_dairy(self):
        orders = [{"date": "2026-10-01", "status": "تحویل شده", "amount_toman": 999999,
                   "items": [{"name": "شیر بادام", "quantity": 1, "unit_price_toman": 99000}]}]
        core = BasketMindCore(orders, coverage={"complete_sync": True}, calendar="gregorian")
        result = core.compare_category_months("لبنیات", as_of_date=date(2026, 11, 2))
        self.assertEqual(result["evidence"]["newer_month"]["known_spend_toman"], "0")

    def test_empty_dataset_does_not_claim_zero_category_spend(self):
        core = BasketMindCore([], coverage={"complete_sync": False}, calendar="jalali")
        result = core.compare_category_months("لبنیات", as_of_date=date(2026, 10, 24))
        self.assertEqual(result["status"], "data_insufficient")
        self.assertNotIn("تومان", result["answer"])

    def test_unknown_category_causes_partial_not_false_exactness(self):
        orders = [{"date": "2026-10-01", "status": "تحویل شده", "amount_toman": 100000,
                   "items": [{"name": "محصول عجیب ناشناخته", "quantity": 1, "unit_price_toman": 100000}]}]
        result = BasketMindCore(orders, coverage={"complete_sync": True}, calendar="gregorian").compare_category_months("لبنیات", as_of_date=date(2026, 11, 2))
        self.assertEqual(result["status"], "partial")
        self.assertTrue(any("طبقه‌بندی" in x for x in result["warnings"]))

    def test_missing_item_price_causes_partial_category_spend(self):
        orders = [{"date": "2026-10-01", "status": "تحویل شده", "amount_toman": 100000,
                   "items": [{"name": "شیر", "quantity": 1}]}]
        result = BasketMindCore(orders, coverage={"complete_sync": True}, calendar="gregorian").compare_category_months("لبنیات", as_of_date=date(2026, 11, 2))
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["evidence"]["newer_month"]["known_spend_toman"], "0")
        self.assertEqual(result["evidence"]["newer_month"]["missing_price_lines"], 1)

    def test_question_three_reorder_suggestions_and_honest_stock_disclaimer(self):
        result = self.core.answer_question("بر اساس خریدهای قبلی چه چیزهایی را دوباره بخرم؟", as_of_date=self.as_of)
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["intent"], "reorder_suggestions")
        self.assertGreaterEqual(len(result["evidence"]["suggestions"]), 1)
        self.assertIn("موجودی واقعی خانه", result["answer"])

    def test_reorder_suggestion_requires_three_purchase_dates(self):
        orders = [
            {"date": "2026-09-01", "status": "تحویل شده", "items": [{"name": "زعفران", "quantity": 1, "unit_price_toman": 100000}]},
            {"date": "2026-09-15", "status": "تحویل شده", "items": [{"name": "زعفران", "quantity": 1, "unit_price_toman": 100000}]},
        ]
        result = BasketMindCore(orders, coverage={"complete_sync": True}, calendar="gregorian").reorder_suggestions(as_of_date=date(2026, 10, 1))
        self.assertEqual(result["evidence"]["suggestions"], [])
        self.assertIn("کافی", result["answer"])

    def test_duplicate_product_lines_on_same_date_are_one_purchase_event(self):
        orders = []
        for day in (1, 15):
            orders.append({"date": f"2026-09-{day:02d}", "status": "تحویل شده",
                           "items": [{"name": "برنج", "quantity": 1, "unit_price_toman": 90000},
                                     {"name": "برنج", "quantity": 1, "unit_price_toman": 90000}]})
        result = BasketMindCore(orders, coverage={"complete_sync": True}, calendar="gregorian").reorder_suggestions(as_of_date=date(2026, 10, 1))
        self.assertEqual(result["evidence"]["suggestions"], [])

    def test_unknown_question_is_not_guessed(self):
        result = self.core.answer_question("آیا فردا اکالا تخفیف می‌دهد؟", as_of_date=self.as_of)
        self.assertEqual(result["status"], "unsupported")
        self.assertIsNone(result["answer"])

    def test_incomplete_sync_warning_is_visible(self):
        core = BasketMindCore(self.orders, coverage={"complete_sync": False, "note": "همگام‌سازی ناقص است"})
        result = core.last_purchase("شیر بادام")
        self.assertEqual(result["status"], "partial")
        self.assertIn("همگام‌سازی ناقص است", result["answer"])

    def test_core_indexes_order_lines_once_for_reuse(self):
        self.assertEqual(sum(len(group) for group in self.core.lines_by_order), len(self.core.lines))
        self.assertEqual(len(self.core.order_dates), len(self.orders))
        self.assertEqual(len(self.core.order_eligible), len(self.orders))


if __name__ == "__main__":
    unittest.main()
