from __future__ import annotations

import shutil
import sys
import tempfile
import types
import unittest
from pathlib import Path

import apply_product_core

GATE = apply_product_core.CURRENT_GATE


def make_v31_fixture() -> str:
    return '''from typing import Any
from analytics_agent import run_analytics_agent


def handler(consent, archived, user_message, orders, total_records, synchronized, agent_public):
    if not consent:
        raise ChatError("consent_required", "برای فرستادن خلاصه سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی، ابتدا اجازه‌ات را تأیید کن.", 428)
    archived = archived or []
    try:
        orders = _cached_orders()
        total_records = 1
        synchronized = True
    except ChatError:
        raise
    context = _build_data_context(orders, total_records, user_message, synchronized)
    try:
        agent_result = run_analytics_agent(orders, user_message, context.get("coverage", {}))
    except Exception:
        agent_result = {"status": "agent_error", "harness": {"passed": False}}
    agent_public = {"status": agent_result.get("status")}
    if agent_result.get("status") == "verified" and agent_result.get("harness", {}).get("passed") is True and agent_result.get("direct_answer"):
        return {"ok": True, "answer": agent_result["direct_answer"]}
    context["analytics_agent"] = agent_public
    # The existing UI consent gate is preserved; verified analytics skip OpenRouter after consent.
    key = _openrouter_key()
    if not key:
        raise ChatError("openrouter_key_missing", "missing", 503)
    system_prompt = "test"
    return {"ok": True}
'''


class InstallerTests(unittest.TestCase):
    def test_patcher_adds_local_route_and_external_consent_guard(self):
        source = make_v31_fixture()
        updated = apply_product_core.patch_server(source)
        self.assertIn("from basketmind_product_adapter import try_answer_product_question", updated)
        self.assertIn("allow_external_llm = bool(consent)", updated)
        self.assertIn("product_core_result = try_answer_product_question", updated)
        self.assertIn("تحلیل‌های محلی BasketMind بدون ارسال داده به مدل اجرا می‌شوند", updated)
        self.assertLess(updated.index("product_core_result = try_answer_product_question"), updated.index("context = _build_data_context"))
        self.assertLess(updated.index("if not allow_external_llm:"), updated.index("key = _openrouter_key()"))
        compile(updated, "server.py", "exec")

    def test_patcher_fails_closed_if_an_anchor_changes(self):
        source = make_v31_fixture().replace("orders = _cached_orders()", "orders = read_orders()")
        with self.assertRaises(RuntimeError):
            apply_product_core.patch_server(source)
        self.assertNotIn("basketmind_product_adapter", source)

    def test_patcher_refuses_second_application(self):
        updated = apply_product_core.patch_server(make_v31_fixture())
        with self.assertRaises(RuntimeError):
            apply_product_core.patch_server(updated)

    def test_preflight_is_read_only(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            app = root / "app"
            app.mkdir()
            (app / "server.py").write_text(make_v31_fixture(), encoding="utf-8")
            original = (app / "server.py").read_bytes()
            report = apply_product_core.preflight(app, Path(__file__).resolve().parents[1])
            self.assertEqual(report["status"], "preflight_passed")
            self.assertEqual((app / "server.py").read_bytes(), original)
            self.assertFalse((app / ".data").exists())

    def test_install_creates_backup_and_preserves_existing_data(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            app = root / "app"
            app.mkdir()
            (app / "server.py").write_text(make_v31_fixture(), encoding="utf-8")
            data_dir = app / ".data"
            data_dir.mkdir()
            sentinel = data_dir / "preserve-me.txt"
            sentinel.write_text("not a database; preservation sentinel", encoding="utf-8")
            original = (app / "server.py").read_bytes()
            report = apply_product_core.apply(app, Path(__file__).resolve().parents[1])
            self.assertEqual(report["status"], "installed")
            self.assertNotEqual((app / "server.py").read_bytes(), original)
            self.assertTrue(Path(report["backup"]).is_file())
            self.assertEqual(Path(report["backup"]).read_bytes(), original)
            self.assertEqual(sentinel.read_text(encoding="utf-8"), "not a database; preservation sentinel")
            for name in ("basketmind_product_core.py", "basketmind_product_adapter.py", "product_aliases.json"):
                self.assertTrue((app / name).is_file())
            self.assertIn("try_answer_product_question", (app / "server.py").read_text(encoding="utf-8"))

    def test_realistic_v31_fixture_answers_locally_without_llm_consent_or_context_build(self):
        fixture = Path(__file__).parent / "fixtures" / "server_v31_synthetic_fixture.py"
        source = fixture.read_text(encoding="utf-8")
        patched = apply_product_core.patch_server(source)
        fake = types.ModuleType("analytics_agent")
        fake.run_analytics_agent = lambda *args, **kwargs: {
            "status": "unsupported", "tool": "none", "intent": "unknown", "direct_answer": None,
            "evidence": {}, "harness": {"passed": True, "checks": ["unsupported"]}}
        prior = sys.modules.get("analytics_agent")
        sys.modules["analytics_agent"] = fake
        try:
            namespace = {"__name__": "synthetic_v31_runtime"}
            exec(compile(patched, "synthetic_v31_runtime.py", "exec"), namespace)
        finally:
            if prior is None:
                sys.modules.pop("analytics_agent", None)
            else:
                sys.modules["analytics_agent"] = prior
        namespace["_build_data_context"] = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("local core should skip prompt context"))
        result = namespace["_chat_with_openrouter"]("آخرین بار نان را کی خریدم و قیمتش چقدر بود؟", [], False)
        self.assertTrue(result["ok"])
        self.assertEqual(result["model"], "BasketMind Local Product Core v1")
        self.assertIn("آخرین خرید ثبت‌شده", result["answer"])
        self.assertNotIn("تومان", result["answer"])  # source fixture has no item price; order total is not attributed to bread

    def test_realistic_v31_fixture_requires_consent_before_external_llm_fallback(self):
        fixture = Path(__file__).parent / "fixtures" / "server_v31_synthetic_fixture.py"
        source = apply_product_core.patch_server(fixture.read_text(encoding="utf-8"))
        fake = types.ModuleType("analytics_agent")
        fake.run_analytics_agent = lambda *args, **kwargs: {
            "status": "unsupported", "tool": "none", "intent": "unknown", "direct_answer": None,
            "evidence": {}, "harness": {"passed": True, "checks": ["unsupported"]}}
        prior = sys.modules.get("analytics_agent")
        sys.modules["analytics_agent"] = fake
        try:
            namespace = {"__name__": "synthetic_v31_runtime"}
            exec(compile(source, "synthetic_v31_runtime.py", "exec"), namespace)
        finally:
            if prior is None:
                sys.modules.pop("analytics_agent", None)
            else:
                sys.modules["analytics_agent"] = prior
        with self.assertRaises(namespace["ChatError"]) as exc:
            namespace["_chat_with_openrouter"]("آیا فردا اکالا تخفیف می‌دهد؟", [], False)
        self.assertEqual(exc.exception.code, "consent_required")


    def test_patcher_supports_known_v30_shape_and_marks_family(self):
        fixture = Path(__file__).parent / "fixtures" / "server_v30_synthetic_fixture.py"
        source = fixture.read_text(encoding="utf-8")
        self.assertEqual(apply_product_core.detect_target_family(source), "v3.0_without_analytics_agent")
        patched = apply_product_core.patch_server(source)
        self.assertIn("from basketmind_product_adapter import try_answer_product_question", patched)
        self.assertIn("allow_external_llm = bool(consent)", patched)
        self.assertLess(patched.index("product_core_result = try_answer_product_question"), patched.index("if not allow_external_llm:"))
        self.assertLess(patched.index("if not allow_external_llm:"), patched.index("context = _build_data_context"))
        compile(patched, "server_v30_patched.py", "exec")

    def test_realistic_v30_fixture_answers_local_without_consent_or_external_calls(self):
        fixture = Path(__file__).parent / "fixtures" / "server_v30_synthetic_fixture.py"
        source = apply_product_core.patch_server(fixture.read_text(encoding="utf-8"))
        namespace = {"__name__": "synthetic_v30_runtime"}
        exec(compile(source, "synthetic_v30_runtime.py", "exec"), namespace)
        namespace["_build_data_context"] = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("local route must skip LLM context"))
        namespace["_openrouter_key"] = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("local route must not read model key"))
        result = namespace["_chat_with_openrouter"]("آخرین بار نان را کی خریدم و قیمتش چقدر بود؟", [], False)
        self.assertTrue(result["ok"])
        self.assertFalse(result["llm_called"])
        self.assertFalse(result["external_data_sent"])
        self.assertIn("آخرین خرید ثبت‌شده", result["answer"])
        self.assertNotIn("تومان", result["answer"])

    def test_realistic_v30_fixture_requires_consent_before_external_fallback(self):
        fixture = Path(__file__).parent / "fixtures" / "server_v30_synthetic_fixture.py"
        source = apply_product_core.patch_server(fixture.read_text(encoding="utf-8"))
        namespace = {"__name__": "synthetic_v30_runtime"}
        exec(compile(source, "synthetic_v30_runtime.py", "exec"), namespace)
        with self.assertRaises(namespace["ChatError"]) as exc:
            namespace["_chat_with_openrouter"]("آیا فردا اکالا تخفیف می‌دهد؟", [], False)
        self.assertEqual(exc.exception.code, "consent_required")

    def test_install_refuses_module_collisions_without_overwriting(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            app = root / "app"
            app.mkdir()
            (app / "server.py").write_text(make_v31_fixture(), encoding="utf-8")
            existing = app / "basketmind_product_core.py"
            existing.write_text("customer-owned file", encoding="utf-8")
            source_before = (app / "server.py").read_bytes()
            with self.assertRaises(RuntimeError):
                apply_product_core.apply(app, Path(__file__).resolve().parents[1])
            self.assertEqual(existing.read_text(encoding="utf-8"), "customer-owned file")
            self.assertEqual((app / "server.py").read_bytes(), source_before)


if __name__ == "__main__":
    unittest.main()
