from datetime import date
import unittest

from basketmind_product_core import BasketMindCore
from basketmind_product_adapter import try_answer_product_question, verify_product_result
from examples.sample_orders import build_sample_orders


class ProductAdapterTests(unittest.TestCase):
    def setUp(self):
        self.orders = build_sample_orders()
        self.coverage = {"complete_sync": True, "scope": "synthetic only"}
        self.as_of = date(2026, 10, 24)
        self.core = BasketMindCore(self.orders, coverage=self.coverage, calendar="jalali")

    def test_adapter_responds_locally_to_all_three_question_types(self):
        qs = [
            "آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟",
            "هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟",
            "بر اساس خریدهای قبلی چه چیزهایی را دوباره بخرم؟",
        ]
        for q in qs:
            with self.subTest(question=q):
                result = try_answer_product_question(self.orders, q, self.coverage, self.as_of)
                self.assertIsNotNone(result)
                self.assertEqual(result["status"], "verified")
                self.assertTrue(result["harness"]["passed"])
                self.assertTrue(result["direct_answer"])
                self.assertFalse(result["llm_called"])
                self.assertFalse(result["external_data_sent"])

    def test_adapter_falls_through_for_unsupported_question(self):
        result = try_answer_product_question(self.orders, "آیا فردا اکالا تخفیف می‌دهد؟", self.coverage, self.as_of)
        self.assertIsNone(result)

    def test_harness_catches_mutated_monthly_amount(self):
        result = self.core.answer_question("هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟", as_of_date=self.as_of)
        result["evidence"]["change_toman"] = "1"
        checked = verify_product_result(self.core, result, self.as_of)
        self.assertFalse(checked["passed"])
        self.assertIn("category_change_recalculation_failed", checked["checks"])

    def test_harness_catches_mutated_last_purchase_date(self):
        result = self.core.answer_question("آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟", as_of_date=self.as_of)
        result["evidence"]["last_purchase_date"] = "2020-01-01"
        checked = verify_product_result(self.core, result, self.as_of)
        self.assertFalse(checked["passed"])
        self.assertIn("last_purchase_date_recalculation_failed", checked["checks"])

    def test_harness_catches_forged_reorder_interval(self):
        result = self.core.answer_question("بر اساس خریدهای قبلی چه چیزهایی را دوباره بخرم؟", as_of_date=self.as_of)
        result["evidence"]["suggestions"][0]["median_repurchase_interval_days"] += 100
        checked = verify_product_result(self.core, result, self.as_of)
        self.assertFalse(checked["passed"])
        self.assertIn("reorder_median_repurchase_interval_days_recalculation_failed", checked["checks"])


    def test_reorder_harness_catches_removed_suggestion(self):
        result = self.core.answer_question("بر اساس خریدهای قبلی چه چیزهایی را دوباره بخرم؟", as_of_date=self.as_of)
        result["evidence"]["suggestions"].pop()
        checked = verify_product_result(self.core, result, self.as_of)
        self.assertFalse(checked["passed"])
        self.assertIn("reorder_suggestion_set_does_not_match_independent_reference", checked["checks"])

    def test_category_harness_catches_forged_month_boundary(self):
        result = self.core.answer_question("هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟", as_of_date=self.as_of)
        result["evidence"]["newer_month"]["start"] = "2026-01-01"
        checked = verify_product_result(self.core, result, self.as_of)
        self.assertFalse(checked["passed"])
        self.assertIn("newer_month_does_not_match_expected_calendar_month", checked["checks"])

    def test_category_harness_catches_swapped_category_even_if_numbers_are_self_consistent(self):
        result = self.core.answer_question("هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟", as_of_date=self.as_of)
        result["evidence"]["category"] = "مواد غذایی خشک"
        checked = verify_product_result(
            self.core, result, self.as_of,
            query="هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟",
        )
        self.assertFalse(checked["passed"])
        self.assertIn("category_selection_does_not_match_unique_query_category", checked["checks"])

    def test_category_harness_rejects_question_with_two_categories(self):
        result = self.core.answer_question("هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟", as_of_date=self.as_of)
        checked = verify_product_result(
            self.core, result, self.as_of,
            query="هزینهٔ لبنیات و مواد غذایی خشک در ماه گذشته چقدر تغییر کرد؟",
        )
        self.assertFalse(checked["passed"])
        self.assertIn("category_selection_does_not_match_unique_query_category", checked["checks"])

    def test_two_categories_in_question_gets_clarification_not_wrong_single_category(self):
        result = try_answer_product_question(
            self.orders,
            "هزینهٔ لبنیات و مواد غذایی خشک در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟",
            self.coverage,
            self.as_of,
        )
        self.assertIsNotNone(result)
        self.assertEqual(result["status"], "clarification_required")
        self.assertTrue(result["harness"]["passed"])
        self.assertIn("بیش از یک دسته", result["direct_answer"])
        self.assertFalse(result["llm_called"])

    def test_category_harness_catches_forged_month_label(self):
        result = self.core.answer_question("هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟", as_of_date=self.as_of)
        result["evidence"]["newer_month"]["label"] = "فروردین ۱۴۰۰"
        checked = verify_product_result(self.core, result, self.as_of)
        self.assertFalse(checked["passed"])
        self.assertIn("newer_month_label_does_not_match_calendar_boundary", checked["checks"])

    def test_product_harness_catches_evidence_swapped_to_plain_milk(self):
        result = self.core.answer_question("آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟", as_of_date=self.as_of)
        result["evidence"]["product"] = "شیر"
        checked = verify_product_result(self.core, result, self.as_of, query="آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟")
        self.assertFalse(checked["passed"])
        self.assertIn("product_selection_does_not_match_unique_query_candidate", checked["checks"])

    def test_reorder_harness_does_not_allow_loosening_minimum_event_policy(self):
        result = self.core.answer_question("بر اساس خریدهای قبلی چه چیزهایی را دوباره بخرم؟", as_of_date=self.as_of)
        result["evidence"]["minimum_purchase_events"] = 1
        checked = verify_product_result(self.core, result, self.as_of)
        self.assertFalse(checked["passed"])
        self.assertIn("reorder_minimum_events_policy_mismatch", checked["checks"])

    def test_adapter_renders_answer_from_verified_evidence_not_draft(self):
        result = try_answer_product_question(self.orders, "آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟", self.coverage, self.as_of)
        self.assertIsNotNone(result)
        self.assertIn("۱۰۰٬۰۰۰ تومان", result["direct_answer"])
        self.assertNotIn("شیر معمولی", result["direct_answer"])

    def test_oracle_category_is_independent_and_excludes_plant_milk(self):
        from basketmind_product_adapter import _oracle_category
        self.assertEqual(_oracle_category({"name": "شیر بادام"}, "شیر بادام"), "جایگزین‌های گیاهی")
        self.assertEqual(_oracle_category({"name": "شیر کم چرب"}, "شیر کم چرب"), "لبنیات")


if __name__ == "__main__":
    unittest.main()
