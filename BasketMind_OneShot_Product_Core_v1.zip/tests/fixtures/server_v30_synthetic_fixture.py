from typing import Any
import json
MAX_CHAT_MESSAGE_CHARS = 2000

class ChatError(Exception):
    def __init__(self, code, message="", status=500):
        self.code, self.message, self.status = code, message, status

ORDERS = [{"date": "2026-01-01", "amount_toman": 90000, "status": "تحویل شده",
           "items": [{"name": "نان", "quantity": 2}]}]
def _cached_orders(): return ORDERS
def _meta_get(key, default=""):
    return {"provider_total": "1", "last_synced_at": "2026-01-01", "sync_complete": "true", "sync_truncated": "false"}.get(key, default)
def _build_data_context(orders, total, query, synchronized):
    return {"coverage": {"complete_sync": True, "scope": "همگام‌سازی کامل", "note": ""}}
def _fetch_recent_orders(): raise AssertionError("the cache fixture should be used")
def _openrouter_key(): return "fake-test-only-key"
def _chat_with_openrouter(user_message, history, consent, archived=None):
    if not consent:
        raise ChatError("consent_required", "برای فرستادن خلاصه سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی، ابتدا اجازه‌ات را تأیید کن.", 428)
    archived = archived or []
    key = _openrouter_key()
    if not key:
        raise ChatError("openrouter_key_missing", "سکرت OPENROUTER_API_KEY در محیط سرور پیدا نشد. آن را در بخش Codespaces Secrets بررسی کن.", 503)
    try:
        orders = _cached_orders()
        cached_total = _meta_get("provider_total", "")
        total_records = int(cached_total) if cached_total.isdigit() else 0
        synchronized = bool(orders) and _meta_get("last_synced_at", "") != ""
        if not orders:
            orders, total_records = _fetch_recent_orders()
            synchronized = False
    except ChatError:
        raise
    context = _build_data_context(orders, total_records, user_message, synchronized)
    system_prompt = json.dumps(context, ensure_ascii=False)
    return {"ok": True, "answer": system_prompt, "model": "openrouter/free"}
