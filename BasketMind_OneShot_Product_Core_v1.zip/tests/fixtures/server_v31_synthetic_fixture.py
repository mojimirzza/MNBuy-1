from typing import Any
import json
MAX_CHAT_MESSAGE_CHARS = 2000
MAX_HISTORY_MESSAGES = 12
LAST_MESSAGES = []
LAST_SYSTEM_PROMPT = ""
from analytics_agent import run_analytics_agent

class ChatError(Exception):
    def __init__(self, code, message="", status=500):
        self.code, self.message, self.status = code, message, status

ORDERS = [{"date": "2026-01-01", "amount_toman": 90000, "status": "تحویل شده",
           "items": [{"name": "نان", "quantity": 2}]}]
def _cached_orders(): return ORDERS
def _meta_get(key, default=""):
    return {"provider_total": "1", "last_synced_at": "2026-01-01", "sync_complete": "true", "sync_truncated": "false"}.get(key, default)
def _build_data_context(orders, total, query, synchronized):
    return {"coverage": {"complete_sync": True, "scope": "همگام‌سازی کامل", "note": ""}}
def _fetch_recent_orders(): raise AssertionError("without consent and with a cache, must not fetch")
def _openrouter_key(): raise AssertionError("local result must bypass OpenRouter")
def _chat_with_openrouter(user_message, history, consent, archived=None):
    if not consent:
        raise ChatError("consent_required", "برای فرستادن خلاصه سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی، ابتدا اجازه‌ات را تأیید کن.", 428)
    archived = archived or []
    try:
        orders = _cached_orders()
        cached_total = _meta_get("provider_total", "")
        total_records = int(cached_total) if cached_total.isdigit() else 0
        synchronized = bool(orders) and _meta_get("last_synced_at", "") != ""
        if not orders:
            orders, total_records = _fetch_recent_orders()
            synchronized = False
        elif not synchronized:
            # Before a full sync, prefer fresh recent orders, but don't discard a useful cache
            # merely because the Okala token expired or the provider is temporarily unavailable.
            try:
                recent_orders, recent_total = _fetch_recent_orders()
                if recent_orders:
                    orders = recent_orders
                total_records = max(total_records, recent_total)
            except ChatError:
                pass
            synchronized = False
    except ChatError:
        raise
    context = _build_data_context(orders, total_records, user_message, synchronized)
    try:
        agent_result = run_analytics_agent(orders, user_message, context.get("coverage", {}))
    except Exception:
        agent_result = {"status": "agent_error", "tool": "fallback_to_llm", "intent": "unknown",
                        "matched_product": None, "evidence": {}, "direct_answer": None,
                        "harness": {"passed": False, "checks": ["agent_exception"]}}
    agent_public = {
        "status": agent_result.get("status"), "tool": agent_result.get("tool"),
        "intent": agent_result.get("intent"), "matched_product": agent_result.get("matched_product"),
        "evidence": agent_result.get("evidence", {}) if agent_result.get("harness", {}).get("passed") is True else {},
        "harness": agent_result.get("harness", {}),
    }
    if agent_result.get("status") == "verified" and agent_result.get("harness", {}).get("passed") is True and agent_result.get("direct_answer"):
        return {"ok": True, "answer": agent_result["direct_answer"],
                "model": "BasketMind Python analytics agent v3.1 (local)",
                "orders_reviewed": len(orders), "data_scope": context["coverage"], "usage": None,
                "analytics_agent": agent_public}
    context["analytics_agent"] = agent_public
    # The existing UI consent gate is preserved; verified analytics skip OpenRouter after consent.
    key = _openrouter_key()
    global LAST_MESSAGES, LAST_SYSTEM_PROMPT
    messages = []
    if archived:
        archive_json = json.dumps(archived, ensure_ascii=False, separators=(",", ":"))
        messages.append({"role": "system", "content": "archive=" + archive_json[:5000]})
    for item in history[-MAX_HISTORY_MESSAGES:]:
        role, content = item.get("role"), item.get("content")
        if role in ("user", "assistant") and isinstance(content, str) and content.strip():
            messages.append({"role": role, "content": content[:1500]})
    messages.append({"role": "user", "content": user_message[:MAX_CHAT_MESSAGE_CHARS]})
    LAST_MESSAGES = messages
    system_prompt = (
        "فیلد analytics_agent نتیجهٔ انتخاب ابزار و بررسی قطعی Harness است؛ اگر status برابر unsupported است یا Harness تأیید نشده، عدد تازه نساز. در سؤال‌های توضیحی، واقعیت ثبت‌شده را از علت یا حدس جدا کن و علتِ اثبات‌نشده نساز. "
        + json.dumps(context, ensure_ascii=False, separators=(",", ":"))
    )
    LAST_SYSTEM_PROMPT = system_prompt
    result = {"model": "openrouter/free"}
    content = "پاسخ آزمایشی مدل"
    usage = {"total_tokens": 3}
    if True:
        return {"ok": True, "answer": content.strip()[:12_000], "model": result.get("model") or _openrouter_model(),
                "orders_reviewed": len(orders), "data_scope": context["coverage"], "usage": usage if isinstance(usage, dict) else None}

class Handler:
    server_version = "BasketMind/3.1"
    def health(self): return {"version": "3.1.0"}
def main(): print("BasketMind v3.1 listening")
