#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
python -m compileall -q .
python -m unittest discover -s tests -v
if python -c 'import pytest' >/dev/null 2>&1; then
  pytest -q
else
  echo "pytest not installed; stdlib unittest suite above is authoritative for this run."
fi
python examples/try_three_questions.py
python performance/benchmark_product_core.py
