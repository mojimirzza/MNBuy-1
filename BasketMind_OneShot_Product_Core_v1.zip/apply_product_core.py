#!/usr/bin/env python3
"""Fail-closed installer for BasketMind's three-question local product core.

This targets only the two exact BasketMind v3.0 and v3.1 source shapes covered by tests.
Default is read-only preflight. Use --apply only after reviewing the detected target and creating a backup/branch.
It never touches SQLite data. If the exact source anchors do not match, it exits without writes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import py_compile
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

IMPORT_ANCHOR = "from analytics_agent import run_analytics_agent\n"
V30_IMPORT_ANCHOR = "from typing import Any\n"
CURRENT_GATE = '''    if not consent:
        raise ChatError("consent_required", "برای فرستادن خلاصه سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی، ابتدا اجازه‌ات را تأیید کن.", 428)
    archived = archived or []
    try:
        orders = _cached_orders()
'''
NEW_GATE = '''    # Local product analytics are allowed without transmitting data externally.
    allow_external_llm = bool(consent)
    archived = archived or []
    try:
        orders = _cached_orders()
'''
V30_OLD_GATE = '''    if not consent:
        raise ChatError("consent_required", "برای فرستادن خلاصه سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی، ابتدا اجازه‌ات را تأیید کن.", 428)
    archived = archived or []
    key = _openrouter_key()
    if not key:
        raise ChatError("openrouter_key_missing", "سکرت OPENROUTER_API_KEY در محیط سرور پیدا نشد. آن را در بخش Codespaces Secrets بررسی کن.", 503)
    try:
        orders = _cached_orders()
'''
V30_NEW_GATE = '''    # Local product analytics are allowed without transmitting data externally.
    allow_external_llm = bool(consent)
    archived = archived or []
    try:
        orders = _cached_orders()
'''
CONTEXT_ANCHOR = '    context = _build_data_context(orders, total_records, user_message, synchronized)\n'
AGENT_ANCHOR = '    try:\n        agent_result = run_analytics_agent(orders, user_message, context.get("coverage", {}))\n'
KEY_ANCHOR = '    key = _openrouter_key()\n'

PRODUCT_BLOCK = '''    # Fast, local product core: avoid building LLM context or calling the model for known tasks.
    try:
        sync_complete_meta = str(_meta_get("sync_complete", "")).strip().lower() in {"true", "1", "yes"}
        sync_truncated_meta = str(_meta_get("sync_truncated", "")).strip().lower() in {"true", "1", "yes"}
    except Exception:
        sync_complete_meta, sync_truncated_meta = False, True
    local_complete_sync = bool(synchronized) and sync_complete_meta and not sync_truncated_meta
    if total_records and int(total_records) > len(orders):
        local_complete_sync = False
    local_coverage = {
        "complete_sync": local_complete_sync,
        "scope": "full_synced_history" if local_complete_sync else "cached_or_recent_orders",
        "orders_reviewed": len(orders),
        "provider_total_records": int(total_records or 0),
        "truncated": sync_truncated_meta,
        "note": "کامل‌بودن همگام‌سازی تاریخچه تأیید نشده است." if not local_complete_sync else "",
    }
    try:
        product_core_result = try_answer_product_question(orders, user_message, local_coverage)
    except Exception:
        # Local-core failure must not crash the existing chat route.
        product_core_result = None
    if product_core_result is not None:
        return {
            "ok": True,
            "answer": product_core_result.get("direct_answer") or "برای جلوگیری از پاسخ نادرست، لطفاً سؤال را روشن‌تر کن.",
            "model": "BasketMind Local Product Core v1",
            "orders_reviewed": len(orders),
            "data_scope": local_coverage,
            "usage": None,
            "analytics_agent": product_core_result,
            "llm_called": False,
            "external_data_sent": False,
        }
'''
CONSENT_GUARD = '''    if not allow_external_llm:
        raise ChatError("consent_required", "برای ارسال خلاصهٔ سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی باید رضایت را تأیید کنی. تحلیل‌های محلی BasketMind بدون ارسال داده به مدل اجرا می‌شوند.", 428)
    key = _openrouter_key()
'''
V30_EXTERNAL_GUARD = '''    if not allow_external_llm:
        raise ChatError("consent_required", "برای ارسال خلاصهٔ سفارش‌ها و بخشی از گفت‌وگو به مدل هوش مصنوعی باید رضایت را تأیید کنی. تحلیل‌های محلی BasketMind بدون ارسال داده به مدل اجرا می‌شوند.", 428)
    key = _openrouter_key()
    if not key:
        raise ChatError("openrouter_key_missing", "سکرت OPENROUTER_API_KEY در محیط سرور پیدا نشد. آن را در بخش Codespaces Secrets بررسی کن.", 503)
'''


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def detect_target_family(source: str) -> str:
    """Identify only the two exact source families this installer knows how to patch."""
    if source.count(IMPORT_ANCHOR) == 1 and source.count(CURRENT_GATE) == 1:
        return "v3.1_with_analytics_agent"
    if source.count(V30_OLD_GATE) == 1 and source.count(V30_IMPORT_ANCHOR) == 1:
        return "v3.0_without_analytics_agent"
    raise RuntimeError("نسخهٔ server.py با هیچ‌یک از دو ساختار شناخته‌شدهٔ v3.0/v3.1 منطبق نیست؛ نصب متوقف شد.")


def patch_server(source: str) -> str:
    """Patch v3.0 or v3.1 only when the complete expected anchors match exactly."""
    if "from basketmind_product_adapter import try_answer_product_question" in source:
        raise RuntimeError("هستهٔ محلی قبلاً وارد شده است؛ از اجرای دوباره جلوگیری شد.")
    family = detect_target_family(source)
    if family == "v3.1_with_analytics_agent":
        for anchor, label in ((CURRENT_GATE, "گیت رضایت v3.1"), (CONTEXT_ANCHOR, "ساخت context"),
                              (AGENT_ANCHOR, "فراخوانی عامل"), (KEY_ANCHOR, "فراخوانی OpenRouter")):
            if source.count(anchor) != 1:
                raise RuntimeError(f"نقطهٔ ادغام «{label}» دقیقاً یک بار پیدا نشد؛ هیچ تغییری اعمال نشد.")
        updated = source.replace(
            IMPORT_ANCHOR,
            IMPORT_ANCHOR + "from basketmind_product_adapter import try_answer_product_question\n",
            1,
        )
        updated = updated.replace(CURRENT_GATE, NEW_GATE, 1)
        updated = updated.replace(CONTEXT_ANCHOR, PRODUCT_BLOCK + CONTEXT_ANCHOR, 1)
        updated = updated.replace(KEY_ANCHOR, CONSENT_GUARD, 1)
        if "allow_external_llm = bool(consent)" not in updated:
            raise RuntimeError("ثبت وضعیت رضایت موفق نبود؛ نصب متوقف شد.")
    elif family == "v3.0_without_analytics_agent":
        if source.count(V30_IMPORT_ANCHOR) != 1:
            raise RuntimeError("نقطهٔ import نسخهٔ v3.0 یکتا نیست؛ نصب متوقف شد.")
        if source.count(CONTEXT_ANCHOR) != 1:
            raise RuntimeError("نقطهٔ ساخت context در نسخهٔ v3.0 یکتا نیست؛ نصب متوقف شد.")
        updated = source.replace(
            V30_IMPORT_ANCHOR,
            V30_IMPORT_ANCHOR + "from basketmind_product_adapter import try_answer_product_question\n",
            1,
        )
        updated = updated.replace(V30_OLD_GATE, V30_NEW_GATE, 1)
        updated = updated.replace(CONTEXT_ANCHOR, PRODUCT_BLOCK + V30_EXTERNAL_GUARD + CONTEXT_ANCHOR, 1)
    else:
        raise RuntimeError("خانوادهٔ سورس پشتیبانی نمی‌شود؛ نصب متوقف شد.")
    if updated.count("from basketmind_product_adapter import try_answer_product_question") != 1:
        raise RuntimeError("import هستهٔ محصول یکتا نیست؛ نصب متوقف شد.")
    if updated.count("product_core_result = try_answer_product_question") != 1:
        raise RuntimeError("مسیر هستهٔ محصول یکتا نیست؛ نصب متوقف شد.")
    compile(updated, "server.py", "exec")
    return updated


def preflight(app_dir: Path, bundle_dir: Path) -> dict:
    source_path = app_dir / "server.py"
    if not source_path.is_file():
        raise RuntimeError(f"server.py پیدا نشد: {source_path}")
    source = source_path.read_text(encoding="utf-8")
    updated = patch_server(source)
    required = [
        bundle_dir / "basketmind_product_core.py",
        bundle_dir / "basketmind_product_adapter.py",
        bundle_dir / "product_aliases.json",
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise RuntimeError("فایل‌های بسته ناقص‌اند: " + ", ".join(missing))
    targets = [app_dir / "basketmind_product_core.py", app_dir / "basketmind_product_adapter.py", app_dir / "product_aliases.json"]
    collisions = [str(path) for path in targets if path.exists()]
    if collisions:
        raise RuntimeError("برای جلوگیری از overwrite، فایل‌های هم‌نام موجودند: " + ", ".join(collisions))
    return {
        "status": "preflight_passed",
        "target_family": detect_target_family(source),
        "app_dir": str(app_dir),
        "server_sha256_before": sha256_text(source),
        "server_sha256_after_patch": sha256_text(updated),
        "output_files": [str(path) for path in targets],
        "sqlite_touched": False,
        "external_calls_made": False,
    }


def apply(app_dir: Path, bundle_dir: Path) -> dict:
    report = preflight(app_dir, bundle_dir)
    source_path = app_dir / "server.py"
    source = source_path.read_text(encoding="utf-8")
    updated = patch_server(source)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_dir = app_dir / ".data" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup_path = backup_dir / f"server.py.bak-product-core-v1-{stamp}"
    created: list[Path] = []
    temp_server: Path | None = None
    try:
        shutil.copy2(source_path, backup_path)
        module_pairs = [
            (bundle_dir / "basketmind_product_core.py", app_dir / "basketmind_product_core.py"),
            (bundle_dir / "basketmind_product_adapter.py", app_dir / "basketmind_product_adapter.py"),
            (bundle_dir / "product_aliases.json", app_dir / "product_aliases.json"),
        ]
        for src, dest in module_pairs:
            if dest.exists():
                raise RuntimeError(f"فایل هنگام نصب ایجاد شده؛ نصب متوقف شد: {dest}")
            shutil.copy2(src, dest)
            created.append(dest)
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=app_dir, prefix=".server.py.product-core.", suffix=".tmp", delete=False) as handle:
            handle.write(updated)
            temp_server = Path(handle.name)
        # Verify without importing or executing the target app.
        py_compile.compile(str(app_dir / "basketmind_product_core.py"), doraise=True)
        py_compile.compile(str(app_dir / "basketmind_product_adapter.py"), doraise=True)
        compile(updated, str(source_path), "exec")
        shutil.copystat(source_path, temp_server)
        temp_server.replace(source_path)
        report.update({"status": "installed", "backup": str(backup_path), "server_sha256_after": sha256_text(updated)})
        return report
    except Exception:
        # Restore the original server and remove only files created by this installer.
        if backup_path.is_file():
            shutil.copy2(backup_path, source_path)
        for path in reversed(created):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
        raise
    finally:
        if temp_server is not None:
            try:
                temp_server.unlink(missing_ok=True)
            except OSError:
                pass


def main() -> int:
    parser = argparse.ArgumentParser(description="Safe local-core patcher for BasketMind v3.1.")
    parser.add_argument("--app-dir", default="basketmind_order_history", help="Folder containing server.py")
    parser.add_argument("--check", action="store_true", help="Read-only preflight (default if --apply is omitted)")
    parser.add_argument("--apply", action="store_true", help="Apply the patch after exact anchors and file collisions are checked")
    args = parser.parse_args()
    app_dir = Path(args.app_dir).expanduser().resolve()
    if not (app_dir / "server.py").is_file() and (Path.cwd() / "server.py").is_file():
        app_dir = Path.cwd().resolve()
    bundle_dir = Path(__file__).resolve().parent
    try:
        report = apply(app_dir, bundle_dir) if args.apply else preflight(app_dir, bundle_dir)
    except Exception as exc:
        print(f"NO-GO: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report["status"] == "installed":
        print("\nاکنون ابتدا آزمون‌ها را اجرا کن و سپس سرور را راه‌اندازی کن:")
        print("  python -m unittest discover -s tests -v")
        print("  python server.py")
    else:
        print("\nفقط پیش‌بررسی خواندنی انجام شد. برای اعمال تغییر، پس از snapshot/branch از --apply استفاده کن.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
