"""BasketMind one-shot core: deterministic answers for three high-value grocery questions.

The module is intentionally dependency-free. It works on the normalized order shape used by
BasketMind v3: order.date/status/amount_toman and order.items[{name, quantity,
unit_price_toman, line_total_toman, category}]. All monetary arithmetic uses Decimal.

This is a product-core module, not yet wired into the user's live Codespaces server.
"""
from __future__ import annotations

import calendar as gregorian_calendar
import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from functools import lru_cache
from statistics import median
from typing import Any, Iterable

PERSIAN_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
CHAR_MAP = str.maketrans({"ي": "ی", "ى": "ی", "ك": "ک", "ۀ": "ه", "ة": "ه", "أ": "ا", "إ": "ا"})
FA_DIGITS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
PERSIAN_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
                  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]

# Small, inspectable starting taxonomy. Production category coverage must be reviewed and extended.
CATEGORY_ALIASES: dict[str, tuple[str, ...]] = {
    "لبنیات": ("لبنیات", "محصولات لبنی", "dairy"),
    "جایگزین‌های گیاهی": ("جایگزین‌های گیاهی", "شیرهای گیاهی", "plant based"),
    "نان و غلات": ("نان و غلات", "نان", "غلات", "bakery", "grains"),
    "میوه و سبزیجات": ("میوه و سبزیجات", "میوه", "سبزیجات", "produce"),
    "گوشت و پروتئین": ("گوشت و پروتئین", "گوشت", "مرغ", "پروتئین", "meat"),
    "مواد شوینده": ("مواد شوینده", "شوینده", "نظافت", "cleaning"),
    "نوشیدنی‌ها": ("نوشیدنی‌ها", "نوشیدنی", "نوشابه", "beverages"),
    "مواد غذایی خشک": ("مواد غذایی خشک", "حبوبات", "برنج", "ماکارونی", "pantry"),
}

# The more specific plant-based entries are checked before dairy entries.
PRODUCT_CATEGORY_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("جایگزین‌های گیاهی", ("شیر بادام", "شیر سویا", "شیر جو دوسر", "شیر نارگیل گیاهی", "ماست گیاهی")),
    ("لبنیات", ("شیر", "ماست", "پنیر", "دوغ", "کره", "خامه", "کشک", "سرشیر", "پنیر خامه ای", "ماست چکیده")),
    ("نان و غلات", ("نان سنگک", "نان بربری", "نان لواش", "نان تافتون", "نان", "باگت", "جو دوسر")),
    ("میوه و سبزیجات", ("سیب زمینی", "گوجه فرنگی", "خیار", "گوجه", "پیاز", "هویج", "سیب", "موز", "پرتقال", "لیمو", "کاهو", "سبزی")),
    ("گوشت و پروتئین", ("سینه مرغ", "مرغ", "گوشت گوسفند", "گوشت گوساله", "گوشت", "ماهی", "تخم مرغ", "تخممرغ")),
    ("مواد شوینده", ("مایع ظرفشویی", "پودر لباسشویی", "مایع لباسشویی", "دستمال کاغذی", "شامپو فرش", "شوینده")),
    ("نوشیدنی‌ها", ("نوشابه", "آب معدنی", "آبمیوه", "چای", "قهوه")),
    ("مواد غذایی خشک", ("برنج", "ماکارونی", "روغن", "رب گوجه", "عدس", "لوبیا", "نخود", "آرد", "شکر")),
)

CANCEL_MARKERS = ("لغو", "لغوشده", "لغو شده", "باطل", "cancel", "canceled", "cancelled")
NONPURCHASE_MARKERS = ("در انتظار پرداخت", "پرداخت نشده", "در انتظار", "pending", "awaiting payment",
                       "مرجوع", "بازگشت وجه کامل", "refunded", "returned")
REORDER_MARKERS = ("دوباره بخرم", "دوباره بخر", "چی بخرم", "چه چیزهایی بخرم", "چه چیزها را بخرم",
                   "فهرست خرید", "لیست خرید", "خرید بعدی", "چی لازم دارم", "چه چیزی لازم دارم")
LAST_PURCHASE_MARKERS = ("آخرین بار", "آخرین دفعه", "آخرین خرید", "کی خریدم", "چه زمانی خریدم", "آخرین مرتبه")
COMPARE_MARKERS = ("نسبت به", "چقدر تغییر", "چقدر بیشتر", "چقدر کمتر", "تغییر کرده", "تغییر کرد", "مقایسه کن")
MONEY_MARKERS = ("هزینه", "خرج", "مبلغ", "پول", "پرداخت", "مصرف")
# Exclude question grammar/action words before comparing user phrases to long store catalog titles.
PRODUCT_QUERY_STOPWORDS = set("""
آخرین بار دفعه مرتبه خرید خریدی خریدم خریده خریدهام خریده ام خریدها خریدهای
کی چه چگونه چطور زمانی زمان تاریخ قیمت قیمتش قیمتشون مبلغ مبلغش هزینه هزینه‌اش خرج پرداخت
چقدر چند چندبار را رو به از در برای با و یا این آن اون هست است بود بوده بودند میشه می‌توانم
میخواهم میخوام لطفا لطفاً بگو بگید کن کنید لطف میشه لطفا بفرما ماه ماهی ماهانه گذشته قبل
نسبت تغییر کرد کرده کرده است شده هستند همه کل سفارش سفارشها سفارشات
چی چیز چیزها چیزهایی دوباره بخرم بخر خرید بعدی بر اساس توجه قبلی احتمالاً احتمالا
تومان ریال راستی چیه هستش
""".split())


@lru_cache(maxsize=16384)
def normalize_text(value: str) -> str:
    value = unicodedata.normalize("NFKC", str(value or "")).translate(CHAR_MAP).translate(PERSIAN_DIGITS).lower()
    value = re.sub(r"[\u064b-\u065f\u0670\u0640]", "", value)
    value = re.sub(r"[^\w]+", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def parse_decimal(value: Any) -> Decimal | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, Decimal):
        return value if value.is_finite() else None
    if isinstance(value, (int, float)):
        # Use str(float) to avoid importing its binary expansion into Decimal.
        try:
            result = Decimal(str(value))
        except InvalidOperation:
            return None
        return result if result.is_finite() else None
    text = str(value).translate(PERSIAN_DIGITS).replace(",", "").replace("٬", "").replace("٫", ".").strip()
    if not text:
        return None
    try:
        result = Decimal(text)
    except InvalidOperation:
        return None
    return result if result.is_finite() else None


def fmt_number(value: Decimal | int | float | None, *, persian_digits: bool = True) -> str:
    if value is None:
        return "نامشخص"
    dec = value if isinstance(value, Decimal) else Decimal(str(value))
    dec = dec.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if dec == dec.to_integral_value():
        text = f"{int(dec):,}".replace(",", "٬")
    else:
        text = f"{dec:,.2f}".replace(",", "٬")
    return text.translate(FA_DIGITS) if persian_digits else text


def _is_gregorian_leap(year: int) -> bool:
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


# Jalali conversion uses the Borkowski algorithm as implemented by jalaali-js (MIT).
# Attribution/license notice is in NOTICE_CALENDAR.txt; keep this tested code isolated.
_JALALI_BREAKS = (-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178)


def _trunc_div(a: int, b: int) -> int:
    """Integer division with truncation toward zero, matching the reference algorithm."""
    return int(a / b)


def _mod_ref(a: int, b: int) -> int:
    return a - _trunc_div(a, b) * b


def _jal_cal(jy: int) -> tuple[int, int, int, int, int]:
    if not (_JALALI_BREAKS[0] <= jy < _JALALI_BREAKS[-1]):
        raise ValueError("Jalali year outside the supported conversion range")
    gy = jy + 621
    leap_j = -14
    jp = _JALALI_BREAKS[0]
    jump = 0
    for jm in _JALALI_BREAKS[1:]:
        jump = jm - jp
        if jy < jm:
            break
        leap_j += _trunc_div(jump, 33) * 8 + _trunc_div(_mod_ref(jump, 33), 4)
        jp = jm
    n = jy - jp
    leap_j += _trunc_div(n, 33) * 8 + _trunc_div(_mod_ref(n, 33) + 3, 4)
    if _mod_ref(jump, 33) == 4 and jump - n == 4:
        leap_j += 1
    leap_g = _trunc_div(gy, 4) - _trunc_div((_trunc_div(gy, 100) + 1) * 3, 4) - 150
    march = 20 + leap_j - leap_g
    adjusted = n - jump + _trunc_div(jump + 4, 33) * 33 if jump - n < 6 else n
    leap = _mod_ref(_mod_ref(adjusted + 1, 33) - 1, 4)
    if leap == -1:
        leap = 4
    return gy, march, jump, n, leap


def _g2d(gy: int, gm: int, gd: int) -> int:
    d = _trunc_div((gy + _trunc_div(gm - 8, 6) + 100100) * 1461, 4)
    d += _trunc_div(153 * _mod_ref(gm + 9, 12) + 2, 5) + gd - 34840408
    d = d - _trunc_div(_trunc_div(gy + 100100 + _trunc_div(gm - 8, 6), 100) * 3, 4) + 752
    return d


def _d2g(jdn: int) -> tuple[int, int, int]:
    j = 4 * jdn + 139361631
    j = j + _trunc_div(_trunc_div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908
    i = _trunc_div(_mod_ref(j, 1461), 4) * 5 + 308
    gd = _trunc_div(_mod_ref(i, 153), 5) + 1
    gm = _mod_ref(_trunc_div(i, 153), 12) + 1
    gy = _trunc_div(j, 1461) - 100100 + _trunc_div(8 - gm, 6)
    return gy, gm, gd


def _j2d(jy: int, jm: int, jd: int) -> int:
    gy, march, _jump, _n, _leap = _jal_cal(jy)
    return _g2d(gy, 3, march) + (jm - 1) * 31 - _trunc_div(jm, 7) * (jm - 7) + jd - 1


def _d2j(jdn: int) -> tuple[int, int, int]:
    gy, _gm, _gd = _d2g(jdn)
    jy = min(gy - 621, _JALALI_BREAKS[-1] - 1)
    cal_gy, march, _jump, _n, leap = _jal_cal(jy)
    first_day = _g2d(cal_gy, 3, march)
    k = jdn - first_day
    if k >= 0:
        if k <= 185:
            return jy, 1 + _trunc_div(k, 31), _mod_ref(k, 31) + 1
        k -= 186
    else:
        jy -= 1
        k += 179
        if leap == 1:
            k += 1
    return jy, 7 + _trunc_div(k, 30), _mod_ref(k, 30) + 1


def _jalali_month_length(year: int, month: int) -> int:
    if month <= 6:
        return 31
    if month <= 11:
        return 30
    _gy, _march, jump, n, _leap = _jal_cal(year)
    adjusted = n - jump + _trunc_div(jump + 4, 33) * 33 if jump - n < 6 else n
    leap = _mod_ref(_mod_ref(adjusted + 1, 33) - 1, 4)
    if leap == -1:
        leap = 4
    return 30 if leap == 0 else 29


def gregorian_to_jalali(gy: int, gm: int, gd: int) -> tuple[int, int, int]:
    """Borkowski-calendar conversion (tested over modern Gregorian dates)."""
    if not (1 <= gm <= 12 and 1 <= gd <= gregorian_calendar.monthrange(gy, gm)[1]):
        raise ValueError("Invalid Gregorian date")
    return _d2j(_g2d(gy, gm, gd))


def jalali_to_gregorian(jy: int, jm: int, jd: int) -> date:
    """Convert a valid Jalali date to Gregorian using the Borkowski algorithm."""
    if not (1 <= jm <= 12 and 1 <= jd <= _jalali_month_length(jy, jm)):
        raise ValueError("Invalid Jalali date")
    gy, gm, gd = _d2g(_j2d(jy, jm, jd))
    return date(gy, gm, gd)


def parse_order_date(value: Any) -> date | None:
    """Parse ISO/Gregorian order dates and YYYY/MM/DD Jalali dates without guessing formats."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip().translate(PERSIAN_DIGITS)
    # Date-only Jalali strings must be detected before fromisoformat: year 1405 is a valid
    # Gregorian year numerically, but in this application it normally signals Solar Hijri.
    match = re.fullmatch(r"\s*(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})\s*", text)
    if match:
        year, month, day = map(int, match.groups())
        if 1200 <= year <= 1499:
            try:
                return jalali_to_gregorian(year, month, day)
            except ValueError:
                return None
        try:
            return date(year, month, day)
        except ValueError:
            return None
    # ISO datetimes, including Z and offsets. Preserve the order's source-local calendar date.
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date()
    except ValueError:
        return None


def _display_date(value: date, calendar: str) -> str:
    if calendar == "jalali":
        y, m, d = gregorian_to_jalali(value.year, value.month, value.day)
        return f"{y:04d}/{m:02d}/{d:02d}".translate(FA_DIGITS)
    return value.isoformat().translate(FA_DIGITS)


def _month_label(year: int, month: int, calendar: str) -> str:
    if calendar == "jalali":
        return f"{PERSIAN_MONTHS[month - 1]} {year}".translate(FA_DIGITS)
    return f"{year:04d}/{month:02d}".translate(FA_DIGITS)


def _previous_month(year: int, month: int) -> tuple[int, int]:
    return (year - 1, 12) if month == 1 else (year, month - 1)


def _month_start(year: int, month: int, calendar: str) -> date:
    return jalali_to_gregorian(year, month, 1) if calendar == "jalali" else date(year, month, 1)


def _closed_month_windows(as_of: date, calendar: str) -> tuple[tuple[date, date, str], tuple[date, date, str]]:
    if calendar == "jalali":
        current_year, current_month, _ = gregorian_to_jalali(as_of.year, as_of.month, as_of.day)
    elif calendar == "gregorian":
        current_year, current_month = as_of.year, as_of.month
    else:
        raise ValueError("calendar must be 'jalali' or 'gregorian'")
    newest_year, newest_month = _previous_month(current_year, current_month)
    older_year, older_month = _previous_month(newest_year, newest_month)

    def bounds(y: int, m: int) -> tuple[date, date, str]:
        start = _month_start(y, m, calendar)
        ny, nm = (y + 1, 1) if m == 12 else (y, m + 1)
        end = _month_start(ny, nm, calendar) - timedelta(days=1)
        return start, end, _month_label(y, m, calendar)

    return bounds(newest_year, newest_month), bounds(older_year, older_month)


def _word_match(haystack: str, phrase: str) -> bool:
    phrase = normalize_text(phrase)
    if not phrase:
        return False
    return re.search(r"(?<!\w)" + re.escape(phrase) + r"(?!\w)", haystack, re.UNICODE) is not None


def _status_is_eligible(status: Any, for_repurchase: bool = False) -> bool:
    text = normalize_text(str(status or ""))
    if not text:
        return True  # source has no status: include but note that the status is unknown
    if any(normalize_text(marker) in text for marker in CANCEL_MARKERS + NONPURCHASE_MARKERS):
        return False
    if for_repurchase and any(marker in text for marker in ("در انتظار", "pending", "پرداخت نشده")):
        return False
    return True


def _canonical_product(name: str, aliases: dict[str, list[str] | tuple[str, ...]]) -> tuple[str, str]:
    normalized = normalize_text(name)
    for canonical, variants in aliases.items():
        choices = {normalize_text(canonical), *(normalize_text(v) for v in variants)}
        if normalized in choices:
            return normalize_text(canonical), canonical
    return normalized, name.strip()


def _parse_item_price(item: dict[str, Any], quantity: Decimal | None, *, allow_derive: bool = True) -> tuple[Decimal | None, Decimal | None]:
    unit = parse_decimal(item.get("unit_price_toman"))
    if unit is not None and unit < 0:
        unit = None
    line_total = parse_decimal(item.get("line_total_toman"))
    if line_total is not None and line_total < 0:
        line_total = None
    if line_total is None and unit is not None and quantity is not None and allow_derive:
        line_total = unit * quantity
    return unit, line_total


def _quantity(item: dict[str, Any]) -> tuple[Decimal | None, bool]:
    if "quantity" not in item or item.get("quantity") is None or item.get("quantity") == "":
        return Decimal("1"), True
    value = parse_decimal(item.get("quantity"))
    return (value, False) if value is not None and value >= 0 else (None, False)


@dataclass(frozen=True)
class _Line:
    order_index: int
    order_date: date | None
    order_status: str
    product_key: str
    product_name: str
    quantity: Decimal | None
    quantity_assumed: bool
    unit_price: Decimal | None
    line_total: Decimal | None
    category: str | None
    date_missing: bool
    eligible: bool
    raw_item: dict[str, Any]


class BasketMindCore:
    """Build once per stable order snapshot; reuse for multiple questions for speed.

    If synchronization changes the order list, instantiate a new core so indexes cannot go stale.
    """
    def __init__(self, orders: Iterable[dict[str, Any]], *,
                 coverage: dict[str, Any] | None = None,
                 product_aliases: dict[str, list[str] | tuple[str, ...]] | None = None,
                 category_aliases: dict[str, list[str] | tuple[str, ...]] | None = None,
                 calendar: str = "jalali") -> None:
        self.orders = list(orders)
        self.coverage = dict(coverage or {})
        self.product_aliases = product_aliases or {}
        self.category_aliases = category_aliases or CATEGORY_ALIASES
        self.calendar = calendar
        self.lines: list[_Line] = []
        self.lines_by_order: list[list[_Line]] = [[] for _ in self.orders]
        self.order_dates: list[date | None] = [parse_order_date(o.get("date") or o.get("date_text")) for o in self.orders]
        self.order_eligible: list[bool] = [_status_is_eligible(o.get("status")) for o in self.orders]
        self.products: dict[str, dict[str, Any]] = {}
        self._index_orders()

    def _category_for_item(self, item: dict[str, Any], product_name: str) -> str | None:
        explicit = item.get("category") or item.get("category_name") or item.get("category_path")
        if explicit:
            normalized_explicit = normalize_text(str(explicit))
            for canonical, aliases in self.category_aliases.items():
                if normalized_explicit in {normalize_text(canonical), *(normalize_text(a) for a in aliases)}:
                    return canonical
            # Explicit but unrecognized source category: not an inference opportunity.
            return "__explicit_other__"
        name = normalize_text(product_name)
        found: list[tuple[int, str]] = []
        for category, phrases in PRODUCT_CATEGORY_RULES:
            for phrase in phrases:
                if _word_match(name, phrase):
                    found.append((len(normalize_text(phrase)), category))
        if not found:
            return None
        max_len = max(length for length, _ in found)
        winners = {category for length, category in found if length == max_len}
        return next(iter(winners)) if len(winners) == 1 else None

    def _index_orders(self) -> None:
        for order_index, order in enumerate(self.orders):
            parsed_date = self.order_dates[order_index]
            status = str(order.get("status") or "")
            eligible = self.order_eligible[order_index]
            raw_items = order.get("items", [])
            if not isinstance(raw_items, list):
                continue
            for raw_item in raw_items:
                if not isinstance(raw_item, dict):
                    continue
                raw_name = str(raw_item.get("name") or raw_item.get("product_name") or "").strip()
                product_key, product_name = _canonical_product(raw_name, self.product_aliases)
                if not product_key:
                    continue
                quantity, quantity_assumed = _quantity(raw_item)
                unit_price, line_total = _parse_item_price(raw_item, quantity, allow_derive=not quantity_assumed)
                category = self._category_for_item(raw_item, raw_name)
                line = _Line(order_index, parsed_date, status, product_key, product_name, quantity,
                             quantity_assumed, unit_price, line_total, category,
                             parsed_date is None, eligible, raw_item)
                self.lines.append(line)
                self.lines_by_order[order_index].append(line)
                product = self.products.setdefault(product_key, {"name": product_name, "lines": []})
                product["lines"].append(line)

    def _coverage_warnings(self) -> list[str]:
        warnings: list[str] = []
        if self.coverage.get("complete_sync") is not True:
            note = str(self.coverage.get("note") or "کامل‌بودن همگام‌سازی تاریخچه تأیید نشده است.")
            warnings.append(note)
        if any(line.date_missing for line in self.lines if line.eligible):
            warnings.append("تاریخ بخشی از سفارش‌ها قابل‌تفسیر نبود؛ ممکن است نتیجهٔ زمانی ناقص باشد.")
        if any(not line.order_status for line in self.lines if line.eligible):
            warnings.append("وضعیت بعضی سفارش‌ها ثبت نشده است.")
        return list(dict.fromkeys(warnings))

    def _catalog_names(self) -> list[str]:
        return sorted({data["name"] for data in self.products.values()}, key=lambda x: normalize_text(x))

    def _match_products_in_text(self, query: str) -> list[str]:
        q = normalize_text(query)
        # First pass: exact full-title and configured alias matches.
        spans_by_key: dict[str, list[tuple[int, int, str]]] = defaultdict(list)
        keys_by_product: dict[str, tuple[str, str]] = {}
        for key, product in self.products.items():
            name = product["name"]
            variants = [name]
            variants.extend(self.product_aliases.get(name, ()))
            normalized_name = normalize_text(name)
            # If a configured canonical phrase is contained in a longer store title, its aliases
            # can match that title; the actual catalog title remains the returned identity.
            for canonical, aliases in self.product_aliases.items():
                canonical_norm = normalize_text(canonical)
                if canonical_norm == key or _word_match(normalized_name, canonical_norm):
                    variants.extend(aliases)
            for variant in variants:
                vn = normalize_text(variant)
                if not vn:
                    continue
                for m in re.finditer(r"(?<!\w)" + re.escape(vn) + r"(?!\w)", q):
                    spans_by_key[key].append((m.start(), m.end(), name))
                    keys_by_product[key] = (key, name)
        direct_matches: set[str] = set(spans_by_key)
        # A shorter product mention completely inside a longer matched product phrase is shadowed.
        all_spans = [(key, span) for key, spans in spans_by_key.items() for span in spans]
        for short_key, short_span in all_spans:
            for long_key, long_span in all_spans:
                if short_key == long_key:
                    continue
                if long_span[0] <= short_span[0] and long_span[1] >= short_span[1] and (long_span[1] - long_span[0]) > (short_span[1] - short_span[0]):
                    direct_matches.discard(short_key)
                    break
        # Second pass: match short descriptive phrases against verbose store titles (brand, size,
        # packaging). A one-token mention is allowed, but if it matches several catalog entries we
        # return all candidates and ask for clarification rather than picking a random variant.
        query_tokens = [token for token in q.split() if token not in PRODUCT_QUERY_STOPWORDS and not token.isdigit()]
        if query_tokens:
            required_overlap = 1 if len(query_tokens) == 1 else 2
            query_set = set(query_tokens)
            for key, product in self.products.items():
                name_tokens = {token for token in normalize_text(product["name"]).split()
                               if token not in PRODUCT_QUERY_STOPWORDS and not token.isdigit()}
                overlap = query_set & name_tokens
                if len(overlap) >= required_overlap:
                    direct_matches.add(key)
                    keys_by_product[key] = (key, product["name"])
        return [keys_by_product[key][1] for key in sorted(direct_matches) if key in keys_by_product]

    def last_purchase(self, product_query: str) -> dict[str, Any]:
        matches = self._match_products_in_text(product_query)
        if len(matches) > 1:
            return {"status": "clarification_required", "intent": "last_purchase",
                    "answer": "در سؤال بیش از یک کالا پیدا کردم: " + "، ".join(matches[:6]) + ". کدام را بررسی کنم؟",
                    "evidence": {"candidate_products": matches}, "warnings": []}
        if not matches:
            names = self._catalog_names()[:8]
            return {"status": "clarification_required", "intent": "last_purchase",
                    "answer": "نام کالا را به‌شکل دقیق‌تر بگو تا خرید اشتباهی را به آن نسبت ندهم.",
                    "evidence": {"available_product_examples": names}, "warnings": []}
        display_name = matches[0]
        key, _ = _canonical_product(display_name, self.product_aliases)
        product = self.products.get(key)
        if not product:
            return {"status": "data_insufficient", "intent": "last_purchase", "answer": "برای این کالا رکورد قابل‌استفاده‌ای پیدا نشد.", "evidence": {}, "warnings": []}
        lines = [line for line in product["lines"] if line.eligible and line.order_date is not None]
        if not lines:
            return {"status": "data_insufficient", "intent": "last_purchase",
                    "answer": f"برای «{display_name}» سفارش قابل‌تاریخ‌گذاری و معتبر پیدا نشد.",
                    "evidence": {"matched_product": display_name}, "warnings": self._coverage_warnings()}
        latest_date = max(line.order_date for line in lines if line.order_date is not None)
        latest_lines = [line for line in lines if line.order_date == latest_date]
        quantities = [line.quantity for line in latest_lines]
        quantity_complete = all(line.quantity is not None and not line.quantity_assumed for line in latest_lines)
        total_quantity = sum((q for q in quantities if q is not None), Decimal("0")) if quantity_complete else None
        known_line_totals = [line.line_total for line in latest_lines]
        total_complete = all(total is not None for total in known_line_totals)
        total_spend = sum((x for x in known_line_totals if x is not None), Decimal("0")) if total_complete else None
        all_unit_prices_known = all(line.unit_price is not None for line in latest_lines)
        unit_average = (total_spend / total_quantity if total_spend is not None and total_quantity not in (None, Decimal("0"))
                        else latest_lines[0].unit_price if len(latest_lines) == 1 else None)
        date_display = _display_date(latest_date, self.calendar)
        warnings = self._coverage_warnings()
        if not total_complete:
            warnings.append("قیمتِ قلمِ کالا در آخرین خرید کامل ثبت نشده است؛ مبلغ کل سفارش به این کالا نسبت داده نشده.")
        if any(line.quantity_assumed for line in latest_lines):
            warnings.append("تعداد برای یک یا چند قلم ثبت نشده بود و مقدار پیش‌فرض ۱ در محاسبه به‌کار رفت.")
        price_text = "قیمت قلم در داده موجود نیست."
        if unit_average is not None and total_complete and quantity_complete:
            price_text = f"میانگین قیمت واحد ثبت‌شده حدود {fmt_number(unit_average)} تومان و مبلغ قلم/اقلام {fmt_number(total_spend)} تومان است."
        elif unit_average is not None:
            price_text = f"قیمت واحد ثبت‌شده {fmt_number(unit_average)} تومان است؛ مبلغ کل قلم به‌دلیل ناقص بودن تعداد یا قیمت ردیف‌ها قابل تأیید نیست."
        elif total_complete:
            price_text = f"مبلغ قلم/اقلام ثبت‌شده {fmt_number(total_spend)} تومان است؛ قیمت واحد یکتا قابل استخراج نیست."
        answer = f"آخرین خرید ثبت‌شدهٔ «{display_name}» در {date_display} بوده است. {price_text}"
        if warnings:
            answer += "\nمحدودیت: " + " ".join(dict.fromkeys(warnings))
        return {"status": "partial" if warnings else "success", "intent": "last_purchase", "answer": answer,
                "evidence": {"product": display_name, "last_purchase_date": latest_date.isoformat(),
                             "quantity": str(total_quantity) if total_quantity is not None else None,
                             "unit_price_toman": str(unit_average) if unit_average is not None and all_unit_prices_known else None,
                             "line_total_toman": str(total_spend) if total_spend is not None else None,
                             "source_order_indices": sorted({line.order_index for line in latest_lines})},
                "warnings": list(dict.fromkeys(warnings))}

    def _category_from_query(self, query: str) -> str | None:
        q = normalize_text(query)
        matches: list[tuple[int, str]] = []
        for canonical, aliases in self.category_aliases.items():
            for alias in (canonical, *aliases):
                if _word_match(q, alias):
                    matches.append((len(normalize_text(alias)), canonical))
        if not matches:
            return None
        max_length = max(length for length, _ in matches)
        winners = {category for length, category in matches if length == max_length}
        return next(iter(winners)) if len(winners) == 1 else None

    def compare_category_months(self, category: str, *, as_of_date: date | None = None) -> dict[str, Any]:
        if category not in self.category_aliases:
            return {"status": "clarification_required", "intent": "category_month_comparison",
                    "answer": f"دستهٔ «{category}» در واژه‌نامهٔ تأییدشده وجود ندارد؛ ابتدا دسته را تعریف یا تأیید کن.",
                    "evidence": {"category": category}, "warnings": []}
        as_of = as_of_date or date.today()
        try:
            newest_window, older_window = _closed_month_windows(as_of, self.calendar)
        except (ValueError, OverflowError):
            return {"status": "data_insufficient", "intent": "category_month_comparison",
                    "answer": "تقویم یا تاریخ مرجع قابل پردازش نیست.", "evidence": {}, "warnings": []}

        def spend_for(window: tuple[date, date, str]) -> dict[str, Any]:
            start, end, label = window
            known_spend = Decimal("0")
            category_lines = priced_lines = missing_price_lines = unknown_category_lines = excluded_orders = undated_orders = quantity_assumed_lines = 0
            orders_in_window = 0
            for order_index, order in enumerate(self.orders):
                od = self.order_dates[order_index]
                if od is None:
                    if self.order_eligible[order_index]:
                        undated_orders += 1
                    continue
                if not (start <= od <= end):
                    continue
                orders_in_window += 1
                if not self.order_eligible[order_index]:
                    excluded_orders += 1
                    continue
                for line in self.lines_by_order[order_index]:
                    if line.category is None:
                        unknown_category_lines += 1
                        continue
                    if line.category != category:
                        continue
                    category_lines += 1
                    if line.quantity_assumed:
                        quantity_assumed_lines += 1
                    if line.line_total is None:
                        missing_price_lines += 1
                        continue
                    known_spend += line.line_total
                    priced_lines += 1
            return {"label": label, "start": start.isoformat(), "end": end.isoformat(),
                    "known_spend_toman": known_spend, "orders_in_window": orders_in_window,
                    "category_lines": category_lines, "priced_lines": priced_lines,
                    "missing_price_lines": missing_price_lines, "quantity_assumed_lines": quantity_assumed_lines,
                    "unknown_category_lines": unknown_category_lines,
                    "undated_orders": undated_orders, "excluded_orders": excluded_orders}

        newest, older = spend_for(newest_window), spend_for(older_window)
        if not self.orders:
            return {"status": "data_insufficient", "intent": "category_month_comparison",
                    "answer": "هیچ سفارش ذخیره‌شده‌ای برای محاسبه پیدا نشد؛ ابتدا تاریخچه را همگام‌سازی کن.",
                    "evidence": {"category": category, "calendar": self.calendar},
                    "warnings": ["هیچ سفارش ذخیره‌شده‌ای در دسترس نیست."]}
        if (self.coverage.get("complete_sync") is not True
                and newest["category_lines"] == 0 and older["category_lines"] == 0
                and newest["unknown_category_lines"] == 0 and older["unknown_category_lines"] == 0):
            return {"status": "data_insufficient", "intent": "category_month_comparison",
                    "answer": "در دادهٔ فعلی قلم شناخته‌شده‌ای از این دسته در دو بازه پیدا نشد، اما همگام‌سازی کامل تأیید نشده است؛ صفر بودن هزینه را نمی‌توان نتیجه گرفت.",
                    "evidence": {"category": category, "calendar": self.calendar,
                                 "newer_month": {"start": newest["start"], "end": newest["end"]},
                                 "older_month": {"start": older["start"], "end": older["end"]}},
                    "warnings": self._coverage_warnings() + ["ممکن است دادهٔ سفارش‌ها ناقص باشد."]}
        change = newest["known_spend_toman"] - older["known_spend_toman"]
        percentage = (change / older["known_spend_toman"] * Decimal("100")) if older["known_spend_toman"] > 0 else None
        warnings: list[str] = self._coverage_warnings()
        for stats in (newest, older):
            if stats["missing_price_lines"]:
                warnings.append(f"در {stats['label']} مبلغ قابل‌محاسبه برای {stats['missing_price_lines']} قلم دسته کامل نیست (قیمت یا تعداد ناقص است).")
            if stats["quantity_assumed_lines"]:
                warnings.append(f"در {stats['label']} تعداد {stats['quantity_assumed_lines']} قلم به‌صورت پیش‌فرض ۱ فرض شده است.")
            if stats["unknown_category_lines"]:
                warnings.append(f"در {stats['label']} طبقه‌بندی {stats['unknown_category_lines']} قلم نامشخص است؛ جمع دسته ممکن است ناقص باشد.")
            if stats["undated_orders"]:
                warnings.append(f"{stats['undated_orders']} سفارش بدون تاریخ در بررسی پوشش دیده شد.")
        warnings = list(dict.fromkeys(warnings))
        percent_text = f" ({fmt_number(percentage)}٪)" if percentage is not None else " (درصد تغییر به‌دلیل صفر بودن/نامشخص بودن مبنای ماه قبل قابل محاسبه نیست)"
        direction = "افزایش" if change > 0 else "کاهش" if change < 0 else "بدون تغییر"
        answer = (f"هزینهٔ ثبت‌شدهٔ دستهٔ «{category}» در {newest['label']}: {fmt_number(newest['known_spend_toman'])} تومان؛ "
                  f"در {older['label']}: {fmt_number(older['known_spend_toman'])} تومان. "
                  f"{direction} نسبت به ماه قبل‌تر: {fmt_number(abs(change))} تومان{percent_text}.")
        if warnings:
            answer += "\nمحدودیت پوشش: " + " ".join(warnings)
        return {"status": "partial" if warnings else "success", "intent": "category_month_comparison", "answer": answer,
                "evidence": {"category": category, "calendar": self.calendar,
                             "newer_month": {**newest, "known_spend_toman": str(newest["known_spend_toman"])},
                             "older_month": {**older, "known_spend_toman": str(older["known_spend_toman"])},
                             "change_toman": str(change), "change_percent": str(percentage) if percentage is not None else None},
                "warnings": warnings}

    def reorder_suggestions(self, *, as_of_date: date | None = None, limit: int = 8,
                            minimum_purchase_events: int = 3, approaching_ratio: Decimal = Decimal("0.75")) -> dict[str, Any]:
        as_of = as_of_date or date.today()
        if limit < 1 or minimum_purchase_events < 3:
            return {"status": "invalid_request", "intent": "reorder_suggestions",
                    "answer": "برای پیشنهاد قابل‌اتکا حداقل ۳ نوبت خرید لازم است و limit باید مثبت باشد.",
                    "evidence": {}, "warnings": []}
        events: dict[str, dict[date, dict[str, Any]]] = defaultdict(dict)
        for line in self.lines:
            if not line.eligible or line.order_date is None:
                continue
            # One purchase event per product per order date; repeat lines on same day do not fake recurrence.
            data = events[line.product_key].setdefault(line.order_date, {"name": line.product_name, "quantity": Decimal("0"), "quantity_known": True})
            if line.quantity is None:
                data["quantity_known"] = False
            elif data["quantity_known"]:
                data["quantity"] += line.quantity
        suggestions = []
        insufficient = 0
        for key, day_map in events.items():
            days = sorted(day_map)
            if len(days) < minimum_purchase_events:
                insufficient += 1
                continue
            gaps = [(days[i] - days[i - 1]).days for i in range(1, len(days))]
            positive_gaps = [gap for gap in gaps if gap > 0]
            if len(positive_gaps) < 2:
                insufficient += 1
                continue
            expected_gap = Decimal(str(median(positive_gaps)))
            elapsed = Decimal((as_of - days[-1]).days)
            ratio = elapsed / expected_gap if expected_gap else Decimal("0")
            if ratio < approaching_ratio:
                continue
            state = "due" if elapsed >= expected_gap else "approaching"
            product = self.products[key]
            latest_day = days[-1]
            latest_quantity = day_map[latest_day]["quantity"] if day_map[latest_day]["quantity_known"] else None
            suggestions.append({"product": product["name"], "state": state,
                                "last_purchase_date": latest_day.isoformat(),
                                "last_purchase_date_display": _display_date(latest_day, self.calendar),
                                "days_since_last_purchase": int(elapsed),
                                "median_repurchase_interval_days": int(expected_gap),
                                "elapsed_to_interval_ratio": str(ratio.quantize(Decimal("0.01"))),
                                "last_purchase_quantity": str(latest_quantity) if latest_quantity is not None else None,
                                "observed_purchase_events": len(days)})
        suggestions.sort(key=lambda row: (row["state"] != "due", -float(row["elapsed_to_interval_ratio"]), row["product"]))
        suggestions = suggestions[:limit]
        warnings = self._coverage_warnings()
        if suggestions:
            lines = []
            for row in suggestions:
                label = "احتمالاً زمان خرید مجدد رسیده" if row["state"] == "due" else "به بازهٔ معمول خرید نزدیک شده"
                lines.append(f"{row['product']}: {label}؛ آخرین خرید {row['last_purchase_date_display']}، "
                             f"{row['days_since_last_purchase']} روز گذشته؛ فاصلهٔ معمول مشاهده‌شده حدود {row['median_repurchase_interval_days']} روز است.")
            answer = "پیشنهادهای احتمالی بر اساس تکرار خریدهای ثبت‌شده:\n" + "\n".join(lines)
        else:
            answer = "از تاریخچهٔ موجود، کالای کافی با حداقل سه نوبت خرید و الگوی زمانی قابل‌محاسبه پیدا نشد."
        answer += "\nاین فهرست از الگوی خرید ساخته شده، نه از موجودی واقعی خانه؛ قبل از خرید بررسی کن."
        if warnings:
            answer += "\nمحدودیت داده: " + " ".join(warnings)
        return {"status": "partial" if warnings else "success", "intent": "reorder_suggestions", "answer": answer,
                "evidence": {"as_of_date": as_of.isoformat(), "calendar": self.calendar,
                             "minimum_purchase_events": minimum_purchase_events, "suggestions": suggestions,
                             "products_with_insufficient_history": insufficient}, "warnings": warnings}

    def answer_question(self, query: str, *, as_of_date: date | None = None) -> dict[str, Any]:
        """Small deterministic Persian router for the three MVP tasks; unknown questions are not guessed."""
        q = normalize_text(query)
        if any(normalize_text(marker) in q for marker in REORDER_MARKERS):
            return self.reorder_suggestions(as_of_date=as_of_date)
        category = self._category_from_query(query)
        if category and any(normalize_text(marker) in q for marker in MONEY_MARKERS) and (
                any(normalize_text(marker) in q for marker in COMPARE_MARKERS) or "ماه قبل" in q or "ماه گذشته" in q):
            return self.compare_category_months(category, as_of_date=as_of_date)
        if any(normalize_text(marker) in q for marker in LAST_PURCHASE_MARKERS) and any(x in q for x in ("قیمت", "چقدر", "هزینه", "کی خریدم", "چه زمانی خریدم")):
            return self.last_purchase(query)
        return {"status": "unsupported", "intent": "unknown", "answer": None,
                "evidence": {"available_features": ["last_purchase", "category_month_comparison", "reorder_suggestions"]},
                "warnings": ["این نسخه فقط سه نوع درخواست تعریف‌شده را به‌صورت قطعی اجرا می‌کند؛ سؤال را دقیق‌تر کن."]}


def main() -> int:
    """Print an executable illustrative demonstration using synthetic data only."""
    from examples.sample_orders import build_sample_orders
    orders = build_sample_orders()
    core = BasketMindCore(orders, coverage={"complete_sync": True, "scope": "دادهٔ مصنوعی نمونه"}, calendar="jalali")
    as_of = date(2026, 10, 24)
    questions = [
        "آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟",
        "هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟",
        "بر اساس خریدهای قبلی چه چیزهایی را دوباره بخرم؟",
    ]
    for index, question in enumerate(questions, 1):
        result = core.answer_question(question, as_of_date=as_of)
        print(f"\n[{index}] {question}\nوضعیت: {result['status']}\n{result['answer']}")
        if result.get("evidence"):
            print("شواهد:", result["evidence"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
