from __future__ import annotations
from datetime import date


def build_sample_orders() -> list[dict]:
    """Purely synthetic orders; these do not represent any real user's purchase history."""
    return [
        {"date": "2026-07-28T10:00:00", "status": "تحویل شده", "amount_toman": 250000,
         "items": [
             {"name": "شیر", "quantity": 2, "unit_price_toman": 50000},
             {"name": "ماست", "quantity": 1, "unit_price_toman": 30000},
             {"name": "شیر بادام", "quantity": 1, "unit_price_toman": 80000},
             {"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000},
         ]},
        {"date": "2026-08-05T15:00:00", "status": "تحویل شده", "amount_toman": 240000,
         "items": [
             {"name": "پنیر", "quantity": 1, "unit_price_toman": 120000},
             {"name": "شیر", "quantity": 1, "unit_price_toman": 50000},
             {"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000},
             {"name": "برنج", "quantity": 1, "unit_price_toman": 90000},
         ]},
        {"date": "2026-08-15T09:00:00", "status": "تحویل شده", "amount_toman": 180000,
         "items": [
             {"name": "شیر بادام", "quantity": 1, "unit_price_toman": 85000},
             {"name": "ماست", "quantity": 2, "unit_price_toman": 30000},
             {"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000},
         ]},
        {"date": "2026-08-25T12:00:00", "status": "تحویل شده", "amount_toman": 400000,
         "items": [
             {"name": "شیر", "quantity": 1, "unit_price_toman": 55000},
             {"name": "پنیر", "quantity": 2, "unit_price_toman": 125000},
             {"name": "ماست", "quantity": 2, "unit_price_toman": 35000},
             {"name": "برنج", "quantity": 1, "unit_price_toman": 90000},
         ]},
        {"date": "2026-09-05T10:00:00", "status": "تحویل شده", "amount_toman": 380000,
         "items": [
             {"name": "شیر بادام", "quantity": 1, "unit_price_toman": 90000},
             {"name": "شیر", "quantity": 1, "unit_price_toman": 55000},
             {"name": "پنیر", "quantity": 2, "unit_price_toman": 125000},
             {"name": "ماست", "quantity": 2, "unit_price_toman": 35000},
             {"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000},
         ]},
        {"date": "2026-09-15T10:00:00", "status": "تحویل شده", "amount_toman": 210000,
         "items": [
             {"name": "شیر بادام", "quantity": 1, "unit_price_toman": 95000},
             {"name": "شیر", "quantity": 1, "unit_price_toman": 60000},
             {"name": "ماست", "quantity": 1, "unit_price_toman": 35000},
             {"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000},
         ]},
        {"date": "2026-09-22T18:00:00", "status": "لغو شده", "amount_toman": 0,
         "items": [{"name": "شیر بادام", "quantity": 4, "unit_price_toman": 20000}]},
        {"date": "2026-10-05T10:00:00", "status": "تحویل شده", "amount_toman": 370000,
         "items": [
             {"name": "شیر بادام", "quantity": 1, "unit_price_toman": 98000},
             {"name": "شیر", "quantity": 1, "unit_price_toman": 65000},
             {"name": "پنیر", "quantity": 1, "unit_price_toman": 130000},
             {"name": "ماست", "quantity": 2, "unit_price_toman": 38000},
             {"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000},
         ]},
        {"date": "2026-10-15T10:00:00", "status": "تحویل شده", "amount_toman": 250000,
         "items": [
             {"name": "شیر بادام", "quantity": 1, "unit_price_toman": 100000},
             {"name": "شیر", "quantity": 1, "unit_price_toman": 65000},
             {"name": "ماست", "quantity": 1, "unit_price_toman": 38000},
             {"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000},
         ]},
        {"date": "2026-06-25T08:00:00", "status": "تحویل شده", "amount_toman": 120000,
         "items": [{"name": "برنج", "quantity": 1, "unit_price_toman": 90000}]},
        {"date": "2026-08-01T08:00:00", "status": "تحویل شده", "amount_toman": 45000,
         "items": [{"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000}]},
        {"date": "2026-09-01T08:00:00", "status": "تحویل شده", "amount_toman": 45000,
         "items": [{"name": "دستمال کاغذی", "quantity": 1, "unit_price_toman": 45000}]},
    ]
