"""Synthetic examples for BasketMind product-core tests."""
