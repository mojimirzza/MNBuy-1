"""Run BasketMind's three supported product questions against synthetic orders."""
from datetime import date
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from basketmind_product_adapter import try_answer_product_question  # noqa: E402
from examples.sample_orders import build_sample_orders  # noqa: E402


QUESTIONS = (
    "آخرین بار شیر بادام را کی خریدم و قیمتش چقدر بود؟",
    "هزینهٔ لبنیات در ماه گذشته نسبت به ماه قبل‌تر چقدر تغییر کرد؟",
    "بر اساس خریدهای قبلی چه چیزهایی را دوباره بخرم؟",
)


def main() -> int:
    orders = build_sample_orders()  # Explicitly synthetic; no customer files/API are read.
    coverage = {"complete_sync": True, "scope": "نمونهٔ مصنوعی فقط برای نمایش"}
    for index, question in enumerate(QUESTIONS, start=1):
        result = try_answer_product_question(orders, question, coverage, as_of_date=date(2026, 10, 24))
        if result is None:
            print(f"{index}. خطا: پرسش نمونه شناسایی نشد: {question}")
            return 2
        print(f"\n{index}. {question}")
        print(f"وضعیت کنترل مستقل: {'تأیید' if result['harness']['passed'] else 'رد'}")
        print(result["direct_answer"])
        print(f"LLM called: {result.get('llm_called', False)} | External data sent: {result.get('external_data_sent', False)}")
        if not result["harness"]["passed"]:
            return 3
    print("\nیادآوری: همهٔ سفارش‌های این اجرا مصنوعی‌اند؛ این خروجی، تاریخچهٔ واقعی کاربر نیست.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
